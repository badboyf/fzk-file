package com.fzk.codegenerate.registry.impl;

import com.fzk.codegenerate.context.ApplicationContext;
import com.fzk.codegenerate.definition.CommonDefinition;
import com.fzk.codegenerate.definition.Definition;
import com.fzk.codegenerate.registry.AbstractSingleDefinitionRegistry;
import com.fzk.codegenerate.util.Constant;
import com.fzk.codegenerate.util.Util;
import com.fzk.codegenerate.wrapper.ModelWrapper;

public class IServiceDefinitionRegistry extends AbstractSingleDefinitionRegistry {

	@Override
	public Definition getDefinition(ModelWrapper model) {
		String name = getName(model);
		String packageName = getPackageName();
		Class<?> baseClass = model.getBaseClass();
		String destFilePath = getDestFilePath(packageName, name);
		String type = getType();
		Definition definition = new CommonDefinition(name, packageName, baseClass, destFilePath, type);

		return definition;
	}

	@Override
	public String getType() {

		return Constant.TYPE_ISERVICE;
	}
	
	public String getDestFilePath(String packageName, String name) {
		String destPathPrefix = ApplicationContext.getInstance().getConfigContext().getApiDestPathPrefix();
		if (destPathPrefix == null) {
			destPathPrefix = getDestPathPrefix();
		}
		
		return destPathPrefix + Util.packageToFolder(packageName) + "/" + name + ".java";
	}
	
	public String getPackageName() {
		String packageSubfix = Constant.PACKAGE_SUBFIX.get(getType());
		String appBasePackage = ApplicationContext.getInstance().getConfigContext().getBasePackage();
		String domainPackage = ApplicationContext.getInstance().getDomainPackage();
		return appBasePackage + "." + domainPackage + "." + packageSubfix;
	}

	@Override
	public boolean needRegist(ModelWrapper model) {

		return model.getType() == ModelWrapper.Type.MODEL;
	}

	@Override
	public String getNamePrefix() {

		return "I";
	}
}
