/*
 * @Title : ModelProcessor.java
 * 
 * @version V1.0
 * 
 * @date：2018年11月1日
 * 
 * @Copyright © 2018 江苏华叶跨域教育科技发展股份有限公司 Corporation. All rights reserved.
 */
package com.fzk.codegenerate.processor;

import com.fzk.codegenerate.definition.Definition;

/** 
 * @ClassName: ModelProcessor 
 * @Description: 
 * @author fengzhikui
 * @date 2018年11月1日 
 *  
 */
public interface DefinitionProcessor {

	void process(Definition definition);
}
