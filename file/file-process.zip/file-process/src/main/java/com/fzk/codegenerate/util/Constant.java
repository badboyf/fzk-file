package com.fzk.codegenerate.util;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Constant {
	public static final String PACKAGE = "package ";
	public static final String IMPORT = "import";
	
	public static final String SRC_MAIN_JAVA = "/src/main/java";
	
	public static final String EXCEPTION_TYPE_EXIST = "Exist";
	public static final String EXCEPTION_TYPE_NOT_EXIST = "NotExist";
	public static final String EXCEPTION_TYPE_VERSION = "VersionWrong";

	public static final String CRD_TYPE_CREATE = "Create";
	public static final String CRD_TYPE_UPDATE = "Update";
	public static final String CRD_TYPE_DELETE = "Delete";
	public static final List<String> CRD_TYPES = Arrays.asList(CRD_TYPE_CREATE, CRD_TYPE_UPDATE, CRD_TYPE_DELETE);
	
//	public static final String EVENT_TYPE_CREATE = "Create";
//	public static final String EVENT_TYPE_UPDATE = "Update";
//	public static final String EVENT_TYPE_DELETE = "Delete";
//	public static final List<String> EVENT_TYPES = Arrays.asList(EVENT_TYPE_CREATE, EVENT_TYPE_UPDATE, EVENT_TYPE_DELETE);
//
//	public static final String RESOLVER_TYPE_CREATE = "Create";
//	public static final String RESOLVER_TYPE_UPDATE = "Update";
//	public static final String RESOLVER_TYPE_DELETE = "Delete";
//	public static final List<String> RESOLVER_TYPES = Arrays.asList(RESOLVER_TYPE_CREATE, RESOLVER_TYPE_UPDATE, RESOLVER_TYPE_DELETE);
	
	public static final String DTO = "DTO";
	public static final String FACTORY = "Factory";
	public static final String ASSEMBLE = "Assemble";
	public static final String REPOSIROTY = "Repository";
	public static final String CRUD_REPOSIROTY = "CRUDReposiroty";
	public static final String EXCEPTION = "Exception";
	public static final String SERVICE = "Service";
	public static final String ISERVICE = "Service";
	public static final String EVENT = "Event";
	public static final String EVENT_VO = "EventVo";
	public static final String EVENT_CONSTANT = "Constant";
	public static final String RESOLVER = "Resolver";
	public static final String SECURITY = "ServiceSecurity";
	public static final String EXCEPTION_REASON = "ExcptionReason";
	public static final String EXCEPTION_HANDLER = "ExcptionHandler";

	public static final String DTO_PACKAGE 					= "api.dto";
	public static final String DOMAIN_MODEL_PACKAGE 		= "domain.model";
	public static final String FACTORY_PACKAGE 				= DOMAIN_MODEL_PACKAGE + ".factory";
	public static final String ASSEMBLE_PACKAGE 			= "service.assemble";
	public static final String REPOSIROTY_PACKAGE 			= DOMAIN_MODEL_PACKAGE + ".repository";
	public static final String INTERNAL_REPOSIROTY_PACKAGE 	= REPOSIROTY_PACKAGE + ".internal";
	public static final String EXCEPTION_PACKAGE 			= "api.exception";
	public static final String ISERVICE_PACKAGE 			= "api.service";
	public static final String SERVICE_PACKAGE 				= "service";
	public static final String EVENT_PACKAGE 				= "domain.message";
	public static final String EVENT_VO_PACKAGE 			= "domain.message";
	public static final String EVENT_CONSTANT_PACKAGE 		= "domain.event";
	public static final String RESOLVER_PACKAGE 			= "infrastructure.resolver";
	public static final String SECURITY_PACKAGE			 	= "security";
	public static final String EXCEPTION_REASON_PACKAGE 	= "service.rest.exception.handler";
	public static final String EXCEPTION_HANDLER_PACKAGE 	= "service.rest.exception.handler";
	public static final String DTO_VO_PACKAGE 				= "api.dto.vo";
	
	public static final String TYPE_FACTORY_TEMPLATE_ENUM = "FACTORY_ENUM";
	
	public static final String TYPE_DTO 				= "DTO";
	public static final String TYPE_FACTORY 			= "FACTORY";
	public static final String TYPE_ASSEMBLE 			= "ASSEMBLE";
	public static final String TYPE_REPOSITORY 			= "REPOSITORY";
	public static final String TYPE_CRUD_REPOSITORY 	= "CRUDREPOSITORY";
	public static final String TYPE_EXCEPTION 			= "EXCEPTION";
	public static final String TYPE_SERVICE 			= "SERVICE";
	public static final String TYPE_ISERVICE	 		= "ISERVICE";
	public static final String TYPE_EVENT 				= "EVENT";
	public static final String TYPE_EVENT_VO 			= "EVENTVO";
	public static final String TYPE_EVENT_CONSTANT 		= "CONSTANT";
	public static final String TYPE_RESOLVER 			= "RESOLVER";
	public static final String TYPE_SECURITY 			= "SECURITY";
	public static final String TYPE_EXCEPTION_REASON	= "EXCEPTION_REASON";
	public static final String TYPE_EXCEPTION_HANDLER	= "EXCEPTION_HANDLER";
	
	public static final Map<String, String> NAME_SUBFIX = new HashMap<>();
	static {
		NAME_SUBFIX.put(TYPE_DTO, 				DTO);
		NAME_SUBFIX.put(TYPE_FACTORY, 			FACTORY);
		NAME_SUBFIX.put(TYPE_ASSEMBLE, 			ASSEMBLE);
		NAME_SUBFIX.put(TYPE_REPOSITORY, 		REPOSIROTY);
		NAME_SUBFIX.put(TYPE_CRUD_REPOSITORY, 	CRUD_REPOSIROTY);
		NAME_SUBFIX.put(TYPE_EXCEPTION, 		EXCEPTION);
		NAME_SUBFIX.put(TYPE_SERVICE, 			SERVICE);
		NAME_SUBFIX.put(TYPE_ISERVICE, 			ISERVICE);
		NAME_SUBFIX.put(TYPE_EVENT, 			EVENT);
		NAME_SUBFIX.put(TYPE_EVENT_VO, 			EVENT_VO);
		NAME_SUBFIX.put(TYPE_EVENT_CONSTANT, 	EVENT_CONSTANT);
		NAME_SUBFIX.put(TYPE_RESOLVER, 			RESOLVER);
		NAME_SUBFIX.put(TYPE_SECURITY, 			SECURITY);
		NAME_SUBFIX.put(TYPE_EXCEPTION_REASON, 	EXCEPTION_REASON);
		NAME_SUBFIX.put(TYPE_EXCEPTION_HANDLER, EXCEPTION_HANDLER);
	}
	
	public static final Map<String, String> PACKAGE_SUBFIX = new HashMap<>();
	static {
		PACKAGE_SUBFIX.put(TYPE_DTO, 				DTO_PACKAGE);
		PACKAGE_SUBFIX.put(TYPE_FACTORY, 			FACTORY_PACKAGE);
		PACKAGE_SUBFIX.put(TYPE_ASSEMBLE, 			ASSEMBLE_PACKAGE);
		PACKAGE_SUBFIX.put(TYPE_REPOSITORY, 		REPOSIROTY_PACKAGE);
		PACKAGE_SUBFIX.put(TYPE_CRUD_REPOSITORY, 	INTERNAL_REPOSIROTY_PACKAGE);
		PACKAGE_SUBFIX.put(TYPE_ISERVICE, 			ISERVICE_PACKAGE);
		PACKAGE_SUBFIX.put(TYPE_SERVICE, 			SERVICE_PACKAGE);
		PACKAGE_SUBFIX.put(TYPE_EVENT, 				EVENT_PACKAGE);
		PACKAGE_SUBFIX.put(TYPE_EVENT_VO, 			EVENT_VO_PACKAGE);
		PACKAGE_SUBFIX.put(TYPE_EVENT_CONSTANT, 	EVENT_CONSTANT_PACKAGE);
		PACKAGE_SUBFIX.put(TYPE_RESOLVER, 			RESOLVER_PACKAGE);
		PACKAGE_SUBFIX.put(TYPE_SECURITY, 			SECURITY_PACKAGE);
		PACKAGE_SUBFIX.put(TYPE_EXCEPTION_REASON, 	EXCEPTION_REASON_PACKAGE);
		PACKAGE_SUBFIX.put(TYPE_EXCEPTION_HANDLER, 	EXCEPTION_HANDLER_PACKAGE);
	}
}
