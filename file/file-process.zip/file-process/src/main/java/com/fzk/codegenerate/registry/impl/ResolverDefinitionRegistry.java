package com.fzk.codegenerate.registry.impl;

import java.util.List;

import com.fzk.codegenerate.context.ApplicationContext;
import com.fzk.codegenerate.definition.Definition;
import com.fzk.codegenerate.definition.TypeCommonDefinition;
import com.fzk.codegenerate.registry.AbstractTypeDefinitionRegistry;
import com.fzk.codegenerate.util.Constant;
import com.fzk.codegenerate.wrapper.ModelWrapper;

public class ResolverDefinitionRegistry extends AbstractTypeDefinitionRegistry {

	@Override
	public Definition getDefinition(ModelWrapper model, String type) {
		String name = getName(model, type);
		String packageName = getPackageName(model);
		Class<?> baseClass = model.getBaseClass();
		String destFilePath = getDestFilePath(packageName, name);
		String definitionType = getType();
		Definition definition = new TypeCommonDefinition(name, packageName, type, baseClass, destFilePath, definitionType);

		return definition;
	}
	
	public String getName(ModelWrapper model, String type) {
		String nameSubfix = getNameSubfix();
		if (nameSubfix == null) {
			nameSubfix = Constant.NAME_SUBFIX.get(getType());
		}
		if (nameSubfix == null) {
			throw new RuntimeException("should suply either method getNameSubfix() or getType() and config the NAME_SUBFIX constant");
		}
		return getNamePrefix() + model.getBaseClass().getSimpleName() + type + "Event" + nameSubfix;
	}

	@Override
	public String getType() {
		return Constant.TYPE_RESOLVER;
	}

	@Override
	public List<String> getTypes(ModelWrapper model) {
		return ApplicationContext.getInstance().getConfigContext().getCrdTypes();
	}

	@Override
	public boolean needRegist(ModelWrapper model) {
		return model.getType() == ModelWrapper.Type.MODEL;
	}
}
