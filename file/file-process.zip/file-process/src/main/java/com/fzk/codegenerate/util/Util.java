package com.fzk.codegenerate.util;

import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;

import com.fzk.codegenerate.context.ModelHolder;
import com.fzk.codegenerate.definition.Definition;
import com.fzk.codegenerate.vo.IdParam;

/** 
 * @ClassName: Util 
 * @Description: 
 * @author fengzhikui
 * @date 2018年5月21日 
 *  
 */
public class Util {
	public static String firstLower(String value) {
		return String.valueOf(value.charAt(0)).toLowerCase() + value.substring(1, value.length());
	}

	public static String firstUpper(String value) {
		return String.valueOf(value.charAt(0)).toUpperCase() + value.substring(1, value.length());
	}

	public static String getSimpleName(Type type) {
		return type.getTypeName().substring(type.getTypeName().lastIndexOf(".") + 1);
	}

	public static Type getOneFXType(Field field) {
		Type innerType = null;
		for (Type t : ((ParameterizedType) field.getGenericType()).getActualTypeArguments()) {
			innerType = t;
		}

		return innerType;
	}

	public static String getImport(String packageName) {
		return Constant.IMPORT + " " + packageName + ";";
	}

	public static String getDTOFields(String showType, String name) {
		return "	@ApiModelProperty(notes = \"\", required = false)\n" + "private " + showType + " " + name + ";\n";
	}

	public static String getPackage(String packageName) {
		return Constant.PACKAGE + " " + packageName + ";";
	}

	public static void addAutowireAssemble(String simpleName, List<String> autowireds) {
		StringBuffer sb = new StringBuffer("");
		sb.append("	private ");
		sb.append(simpleName + Constant.ASSEMBLE);
		sb.append(" ");
		sb.append(Util.firstLower(simpleName) + Constant.ASSEMBLE);
		sb.append(";");
		String autowire = sb.toString();
		if (!autowireds.contains(autowire)) {
			autowireds.add("	@Autowired");
			autowireds.add(autowire);
			autowireds.add("");
		}
	}

	public static void addAutowireFactory(String simpleName, List<String> autowireds) {
		StringBuffer sb = new StringBuffer("");
		sb.append("private ");
		sb.append(simpleName + Constant.FACTORY);
		sb.append(" ");
		sb.append(Util.firstLower(simpleName) + Constant.FACTORY);
		sb.append(";");
		String autowire = sb.toString();
		if (!autowireds.contains(autowire)) {
			autowireds.add("	@Autowired");
			autowireds.add("	" + autowire);
			autowireds.add("");
		}
	}

	public static void addAutowired(String simpleName, List<String> autowireds, String type) {
		Definition definition = ModelHolder.getInstance().get(simpleName, type);
		StringBuffer sb = new StringBuffer("");
		sb.append("private ");
		sb.append(definition.getName());
		sb.append(" ");
		sb.append(Util.firstLower(definition.getName()));
		sb.append(";");
		String autowire = sb.toString();
		if (!autowireds.contains(autowire)) {
			autowireds.add("	@Autowired");
			autowireds.add("	" + autowire);
			autowireds.add("");
		}
	}

	public static String packageToFolder(String packageName) {

		return packageName.replace(".", "/");
	}

	public static Object now() {

		return new SimpleDateFormat("yyyy年MM月dd日").format(new Date());
	}

	public static IdParam getIdParam(Class<?> baseClass) {
		String idType = "";
		String idName = "";
		for (Field field : baseClass.getDeclaredFields()) {
			if (field.isAnnotationPresent(Id.class)) {
				idName = field.getName();
				idType = field.getType().getSimpleName();
				return new IdParam(idType, idName);
			}
		}
		return new IdParam();
	}
}
