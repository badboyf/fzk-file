package com.fzk.codegenerate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import com.fzk.codegenerate.context.ApplicationContext;
import com.fzk.codegenerate.context.ConfigAppContext;
import com.fzk.codegenerate.context.ModelHolder;
import com.fzk.codegenerate.definition.Definition;
import com.fzk.codegenerate.processor.AfterApplicationProcessor;
import com.fzk.codegenerate.processor.ApplicationProcessor;
import com.fzk.codegenerate.processor.BeforeApplicationProcessor;
import com.fzk.codegenerate.processor.DefinitionProcessor;
import com.fzk.codegenerate.processor.before.ClasspathBeforeModelContextProcessor;
import com.fzk.codegenerate.processor.before.SecurityProjectBeforeModelContextProcessor;
import com.fzk.codegenerate.processor.process.PrintNameProcessor;
import com.fzk.codegenerate.processor.process.SortAfterApplicationProcessor;
import com.fzk.codegenerate.registry.DefinitionRegistry;
import com.fzk.codegenerate.registry.impl.AssembleDefiditionRegistry;
import com.fzk.codegenerate.registry.impl.CRUDRepositoryDefiditionRegistry;
import com.fzk.codegenerate.registry.impl.ConstantDefinitionRegistry;
import com.fzk.codegenerate.registry.impl.DtoDefinitionRegistry;
import com.fzk.codegenerate.registry.impl.EventDefinitionRegistry;
import com.fzk.codegenerate.registry.impl.EventVoDefinitionRegistry;
import com.fzk.codegenerate.registry.impl.ExceptionHandlerRegistry;
import com.fzk.codegenerate.registry.impl.ExceptionReasonRegistry;
import com.fzk.codegenerate.registry.impl.FactoryDefinitionRegistry;
import com.fzk.codegenerate.registry.impl.IServiceDefinitionRegistry;
import com.fzk.codegenerate.registry.impl.RepositoryDefinitionRegistry;
import com.fzk.codegenerate.registry.impl.ResolverDefinitionRegistry;
import com.fzk.codegenerate.registry.impl.SecurityDefinitionRegistry;
import com.fzk.codegenerate.registry.impl.ServiceDefinitionRegistry;
import com.fzk.codegenerate.template.generator.CodeGenerator;
import com.fzk.codegenerate.template.generator.LombokCodeGenerator;
import com.fzk.codegenerate.util.Constant;
import com.fzk.codegenerate.wrapper.ModelWrapper;
import com.fzk.codegenerate.wrapper.finder.ModelWrapperFinder;
import com.fzk.codegenerate.wrapper.finder.impl.DefaultModelWrapperFinder;

public class ProcessApplication {
	static String SRC_MAIN_JAVA = "\\src\\main\\java\\";

	public static void main(String[] args) {
		String project = "F:/fzk-notebook/fzk-notebook/zzzzapp/test-project/common-project/common-project-service";
		String destPathPrefix = project;
		String apidestPathPrefix = "F:/fzk-notebook/fzk-notebook/zzzzapp/test-project/api/common-project-api";
		String eventdestPathPrefix = "F:/fzk-notebook/fzk-notebook/zzzzapp/test-project/event/common-project-event";
		String securitydestPathPrefix = "F:\\fzk-notebook\\fzk-notebook\\zzzzapp\\test-project\\common-project\\common-project-security";

		project = "F:\\workspace\\w1\\zxly\\crossdomain-syllabus\\syllabus-usersyllabus\\syllabus-usersyllabus-service" + "";
		destPathPrefix = project + SRC_MAIN_JAVA;
		apidestPathPrefix = "F:\\workspace\\w1\\zxly\\api\\syllabus-usersyllabus-api" + SRC_MAIN_JAVA;
		eventdestPathPrefix = "F:\\workspace\\w1\\zxly\\event\\syllabus-usersyllabus-domain-event" + SRC_MAIN_JAVA;
		securitydestPathPrefix = "F:\\workspace\\w1\\zxly\\crossdomain-syllabus\\syllabus-usersyllabus\\syllabus-usersyllabus-security" + "";
		String processModel = "com.crossdomain.syllabus.usersyllabus.app.domain.model";
		
		String pluginPath = "F:/fzk-notebook/fzk-notebook/file-process/";
		ConfigAppContext context = new ConfigAppContext()
				.project(project)
				.destPathPrefix(destPathPrefix)
				.apiDestPathPrefix(apidestPathPrefix)
				.eventDestPathPrefix(eventdestPathPrefix)
				.securityDestPathPrefix(securitydestPathPrefix)
				.crdTypes(Arrays.asList(Constant.CRD_TYPE_CREATE))
				.processModel(processModel)
				;
		ProcessApplication application = new ProcessApplication(pluginPath, context);
		
		application.run();
		
		System.out.println("done");
	}

	
	private List<ApplicationProcessor> modelContextProcessors = new ArrayList<>();
	private List<DefinitionProcessor> processors = new ArrayList<>();
	private List<DefinitionRegistry> registries = new ArrayList<>();
	ModelWrapperFinder modelWrapperFinder = new DefaultModelWrapperFinder();
	CodeGenerator codeGenerator = new LombokCodeGenerator();

	public ProcessApplication(String pluginPath, ConfigAppContext context) {
		ApplicationContext.getInstance().fresh(pluginPath, context);

//		modelContextProcessors.add(new MavenBeforeModelContextProcessor());
		modelContextProcessors.add(new ClasspathBeforeModelContextProcessor());
		modelContextProcessors.add(new SecurityProjectBeforeModelContextProcessor());

		registries.add(new DtoDefinitionRegistry());
		registries.add(new AssembleDefiditionRegistry());
		registries.add(new FactoryDefinitionRegistry());
		registries.add(new CRUDRepositoryDefiditionRegistry());
		registries.add(new IServiceDefinitionRegistry());
		registries.add(new RepositoryDefinitionRegistry());
		registries.add(new ServiceDefinitionRegistry());
		registries.add(new ExceptionHandlerRegistry());
		registries.add(new ExceptionReasonRegistry());
		registries.add(new SecurityDefinitionRegistry());
		if (!context.getIsSearch()) {
//			registries.add(new ConstantDefinitionRegistry());
//			registries.add(new EventDefinitionRegistry());
//			registries.add(new EventVoDefinitionRegistry());
//			registries.add(new ResolverDefinitionRegistry());
		}
		
		processors.add(new PrintNameProcessor());
		
		modelContextProcessors.add(new SortAfterApplicationProcessor());
	}

	@SuppressWarnings("resource")
	public void run() {
		for (ApplicationProcessor processor : modelContextProcessors) {
			if (processor instanceof BeforeApplicationProcessor) {
				BeforeApplicationProcessor before = (BeforeApplicationProcessor) processor;
				before.process();
			}
		}
		ApplicationContext context = ApplicationContext.getInstance();
		ModelHolder modelHolder = ModelHolder.getInstance();
		List<ModelWrapper> modelWrappers = modelWrapperFinder.find(context.getModelFileDir());
		
		for (ModelWrapper modelWrapper : modelWrappers) {
			for (DefinitionRegistry registry : registries) {
				registry.regist(modelWrapper, modelHolder);
			}
		}

		System.out.println("begin AfterApplicationProcessor:");
		List<Definition> definitions = modelHolder.getDefinitions();
		for (ApplicationProcessor processor : modelContextProcessors) {
			if (processor instanceof AfterApplicationProcessor) {
				AfterApplicationProcessor after = (AfterApplicationProcessor) processor;
				after.process(definitions);
			}
		}
		
		for (DefinitionProcessor processor : processors) {
			for (Definition definition : definitions) {
				processor.process(definition);
			}
		}

		System.out.println("input g to generate, input other to quit");
		Scanner scan = new Scanner(System.in);
		String read = scan.nextLine();
		if ("g".equals(read)) {
			System.out.println("generate file ");
			for (Definition definition : ModelHolder.getInstance().getDefinitions()) {
				try {
					codeGenerator.generate(definition);
				} catch (Exception e) {
					e.printStackTrace();
					throw new RuntimeException(e.getMessage());
				}
			}
		}
	}

}
