package com.fzk.codegenerate.template.generator;

import com.fzk.codegenerate.definition.Definition;

public interface CodeGenerator {

	void generate(Definition definition) throws Exception;

}
