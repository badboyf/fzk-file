/*
 * @Title : IdParam.java
 * 
 * @version V1.0
 * 
 * @date：2018年11月19日
 * 
 * @Copyright © 2018 江苏华叶跨域教育科技发展股份有限公司 Corporation. All rights reserved.
 */
package com.fzk.codegenerate.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/** 
 * @ClassName: IdParam 
 * @Description: 
 * @author fengzhikui
 * @date 2018年11月19日 
 *  
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class IdParam {

	String type;
	String name;
}
