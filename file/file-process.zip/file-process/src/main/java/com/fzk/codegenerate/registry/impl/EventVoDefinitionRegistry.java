package com.fzk.codegenerate.registry.impl;

import com.fzk.codegenerate.context.ApplicationContext;
import com.fzk.codegenerate.context.ConfigAppContext;
import com.fzk.codegenerate.definition.CommonDefinition;
import com.fzk.codegenerate.definition.Definition;
import com.fzk.codegenerate.registry.AbstractSingleDefinitionRegistry;
import com.fzk.codegenerate.util.Constant;
import com.fzk.codegenerate.util.Util;
import com.fzk.codegenerate.wrapper.ModelWrapper;
import com.fzk.codegenerate.wrapper.ModelWrapper.Type;

public class EventVoDefinitionRegistry extends AbstractSingleDefinitionRegistry {

	@Override
	public Definition getDefinition(ModelWrapper model) {
		String name = getName(model);
		String packageName = getPackageName(model);
		Class<?> baseClass = model.getBaseClass();
		String destFilePath = getDestFilePath(packageName, name);
		String type = getType();
		Definition definition = new CommonDefinition(name, packageName, baseClass, destFilePath, type);

		return definition;
	}
	
	public String getPackageName(ModelWrapper wrapper) {
		ApplicationContext context = ApplicationContext.getInstance();
		ConfigAppContext configContext = context.getConfigContext();
		String modelPackage = configContext.getModelPackage();
		String packageSubfix = Constant.PACKAGE_SUBFIX.get(getType());
		String appBasePackage = configContext.getBasePackage();
		String domainPackage = context.getDomainPackage();
		String result = appBasePackage + "." + domainPackage + "." + packageSubfix;
		if (wrapper.getType() == Type.VO) {
			String baseClassPackageName = wrapper.getBaseClass().getPackage().getName();
			String subfix = baseClassPackageName.substring(baseClassPackageName.indexOf(modelPackage) + modelPackage.length() + 1);
			result = appBasePackage + "." + domainPackage + "." + packageSubfix + "." + subfix;
		}
		return result;
	}

	@Override
	public String getType() {

		return Constant.TYPE_EVENT_VO;
	}

	public String getDestFilePath(String packageName, String name) {
		String destPathPrefix = ApplicationContext.getInstance().getConfigContext().getEventDestPathPrefix();
		if (destPathPrefix == null) {
			destPathPrefix = getDestPathPrefix();
		}

		return destPathPrefix + Util.packageToFolder(packageName) + "/" + name + ".java";
	}

	@Override
	public boolean needRegist(ModelWrapper model) {

		return model.getType() != ModelWrapper.Type.MODEL;
	}
}
