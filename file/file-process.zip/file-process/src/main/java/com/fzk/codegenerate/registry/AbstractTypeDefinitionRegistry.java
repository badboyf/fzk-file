package com.fzk.codegenerate.registry;

import java.util.ArrayList;
import java.util.List;

import com.fzk.codegenerate.definition.Definition;
import com.fzk.codegenerate.util.Constant;
import com.fzk.codegenerate.wrapper.ModelWrapper;

public abstract class AbstractTypeDefinitionRegistry extends AbstractDefinitionRegistry {

	public List<Definition> getDefinitions(ModelWrapper model) {
		List<Definition> result = new ArrayList<>();

		for (String type : getTypes(model)) {
			Definition definition = getDefinition(model, type);
			if (definition != null) {
				result.add(definition);
			}
		}

		return result;
	}

	public String getName(ModelWrapper model, String type) {
		String nameSubfix = getNameSubfix();
		if (nameSubfix == null) {
			nameSubfix = Constant.NAME_SUBFIX.get(getType());
		}
		if (nameSubfix == null) {
			throw new RuntimeException("should suply either method getNameSubfix() or getType() and config the NAME_SUBFIX constant");
		}
		return getNamePrefix() + model.getBaseClass().getSimpleName() + type + nameSubfix;
	}

	public  abstract Definition getDefinition(ModelWrapper model, String type);

	public abstract List<String> getTypes(ModelWrapper model);
}
