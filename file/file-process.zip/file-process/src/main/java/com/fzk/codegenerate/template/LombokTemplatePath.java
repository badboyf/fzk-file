/*
 * @Title : TemplatePath.java
 * 
 * @version V1.0
 * @date：2018年11月15日
 * @Copyright © 2018 江苏华叶跨域教育科技发展股份有限公司 Corporation. All rights reserved. 
 */
package com.fzk.codegenerate.template;

import java.util.HashMap;
import java.util.Map;

import com.fzk.codegenerate.context.ApplicationContext;
import com.fzk.codegenerate.definition.Definition;
import com.fzk.codegenerate.util.Constant;

/** 
 * @ClassName: TemplatePath 
 * @Description: 
 * @author fengzhikui
 * @date 2018年11月15日 
 *  
 */
public class LombokTemplatePath implements TemplatePath{
	private static Map<String, String> templatePathMap = null;
	
	@Override
	public String getPath(Definition definition) {
		if (templatePathMap == null) {
			initPath();
		}
		if (definition.getDefinitionType().equals(Constant.TYPE_FACTORY) && definition.getBaseClass().isEnum()) {
			return templatePathMap.get(Constant.TYPE_FACTORY_TEMPLATE_ENUM);
		}
		return templatePathMap.get(definition.getDefinitionType());
	}
	
	private void initPath() {
		String pluginPath = ApplicationContext.getInstance().getPluginPath();
		templatePathMap = new HashMap<>();
		templatePathMap.put(Constant.TYPE_DTO, 			  			pluginPath + "file/lombok-tmplate/DTO");
		templatePathMap.put(Constant.TYPE_FACTORY, 		  			pluginPath + "file/lombok-tmplate/Class_Factory");
		templatePathMap.put(Constant.TYPE_ASSEMBLE, 		  		pluginPath + "file/lombok-tmplate/Assemble");
		templatePathMap.put(Constant.TYPE_REPOSITORY, 	  			pluginPath + "file/lombok-tmplate/Repository");
		templatePathMap.put(Constant.TYPE_CRUD_REPOSITORY, 			pluginPath + "file/lombok-tmplate/CRUD_Reposiroty");
		templatePathMap.put(Constant.TYPE_SERVICE, 		  			pluginPath + "file/lombok-tmplate/Service");
		templatePathMap.put(Constant.TYPE_ISERVICE, 		  		pluginPath + "file/lombok-tmplate/IService");
		templatePathMap.put(Constant.TYPE_EVENT, 					pluginPath + "file/lombok-tmplate/Event");
		templatePathMap.put(Constant.TYPE_EVENT_VO, 		  		pluginPath + "file/lombok-tmplate/Event_Vo");
		templatePathMap.put(Constant.TYPE_EVENT_CONSTANT,  			pluginPath + "file/lombok-tmplate/Constant");
		templatePathMap.put(Constant.TYPE_RESOLVER, 		  		pluginPath + "file/lombok-tmplate/Resolver");
		templatePathMap.put(Constant.TYPE_FACTORY_TEMPLATE_ENUM,	pluginPath + "file/lombok-tmplate/Enum_Factory");
		templatePathMap.put(Constant.TYPE_SECURITY,					pluginPath + "file/lombok-tmplate/Security");
		templatePathMap.put(Constant.TYPE_EXCEPTION_HANDLER,		pluginPath + "file/lombok-tmplate/ExceptionHandler");
		templatePathMap.put(Constant.TYPE_EXCEPTION_REASON,			pluginPath + "file/lombok-tmplate/ExcpetionReason");
	}
}
