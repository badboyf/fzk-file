package com.fzk.codegenerate.definition;

public class TypeCommonDefinition extends CommonDefinition {
	private String type;

	public TypeCommonDefinition() {
	}

	public TypeCommonDefinition(String name, String packageName, String type, Class<?> baseClass, String fileDestPath,
			String definitionType) {
		super(name, packageName, baseClass, fileDestPath, definitionType);
		this.type = type;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
}
