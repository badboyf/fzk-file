package com.fzk.codegenerate.wrapper;

import org.springframework.data.mongodb.core.mapping.Document;

import com.fzk.codegenerate.context.ConfigAppContext;

public class ModelWrapper {
	private Type type;

	private String path;

	private Class<?> baseClass;

	public ModelWrapper() {
	}

	public ModelWrapper(String path) {
		this.path = path;
		String tmp = path.substring(path.indexOf("/target/classes") + "/target/classes".length() + 1, path.length() - ".class".length());
		String toClassPath = tmp.replace("/", ".");
		try {
			this.baseClass = ConfigAppContext.CLASS_LOADER.loadClass(toClassPath);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}
		if (this.baseClass.isAnnotationPresent(Document.class) || this.baseClass.isAnnotationPresent(org.springframework.data.elasticsearch.annotations.Document.class)) {
			this.type = Type.MODEL;
		} else {
			this.type = Type.VO;
		}
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public Class<?> getBaseClass() {
		return baseClass;
	}

	public void setBaseClass(Class<?> baseClass) {
		this.baseClass = baseClass;
	}

	public static enum Type {
		MODEL, VO;
	}
}
