package com.fzk.codegenerate.registry.impl;

import com.fzk.codegenerate.context.ApplicationContext;
import com.fzk.codegenerate.definition.CommonDefinition;
import com.fzk.codegenerate.definition.Definition;
import com.fzk.codegenerate.registry.AbstractSingleDefinitionRegistry;
import com.fzk.codegenerate.util.Constant;
import com.fzk.codegenerate.util.Util;
import com.fzk.codegenerate.wrapper.ModelWrapper;

public class SecurityDefinitionRegistry extends AbstractSingleDefinitionRegistry {

	@Override
	public Definition getDefinition(ModelWrapper model) {
		String name = getName(model);
		String packageName = getPackageName();
		Class<?> baseClass = model.getBaseClass();
		String destFilePath = getDestFilePath(packageName, name);
		if (destFilePath == null) {
			return null;
		}
		String type = getType();
		Definition definition = new CommonDefinition(name, packageName, baseClass, destFilePath, type);

		return definition;
	}

	public String getDestFilePath(String packageName, String name) {

		String securityDestPathPrefix = ApplicationContext.getInstance().getConfigContext().getSecurityDestPathPrefix();
		if (securityDestPathPrefix == null) {
			return null;
		}
		if (securityDestPathPrefix.endsWith("/")) {
			securityDestPathPrefix = securityDestPathPrefix.substring(0, securityDestPathPrefix.length() - 1);
		}
		int beginIndex = securityDestPathPrefix.lastIndexOf("/") + 1;
		int endIndex = securityDestPathPrefix.length();
		String securityProjectName = securityDestPathPrefix.substring(beginIndex, endIndex);
		String subSecurityProjectName = securityProjectName + "-base";

		String subSecurityPath = securityDestPathPrefix + "/" + subSecurityProjectName + "/src/main/java/";

		return subSecurityPath + Util.packageToFolder(packageName) + "/" + name + ".java";
	}

	public String getPackageName() {
		String packageSubfix = Constant.PACKAGE_SUBFIX.get(getType());
		String appBasePackage = ApplicationContext.getInstance().getConfigContext().getBasePackage();
		String domainPackage = ApplicationContext.getInstance().getDomainPackage();
		return appBasePackage + "." + domainPackage + "." + packageSubfix;
	}

	@Override
	public String getType() {

		return Constant.TYPE_SECURITY;
	}

	@Override
	public boolean needRegist(ModelWrapper model) {

		return model.getType() == ModelWrapper.Type.MODEL;
	}

}
