package com.fzk.codegenerate.registry;

import java.util.List;

import com.fzk.codegenerate.context.ApplicationContext;
import com.fzk.codegenerate.context.ModelHolder;
import com.fzk.codegenerate.definition.Definition;
import com.fzk.codegenerate.util.Constant;
import com.fzk.codegenerate.util.Util;
import com.fzk.codegenerate.wrapper.ModelWrapper;

public abstract class AbstractDefinitionRegistry implements DefinitionRegistry {

	@Override
	public void regist(ModelWrapper model, ModelHolder modelHolder) {
		if (!needRegist(model)) {
			return;
		}
		List<Definition> definitions = getDefinitions(model);

		if (definitions != null) {
			for (Definition definition : definitions) {
				modelHolder.registerDefinition(definition);
			}
		}
	}

	public abstract List<Definition> getDefinitions(ModelWrapper model);

	public String getPackageName(ModelWrapper model) {
		String packageSubfix = getPackageSubfix();
		if (packageSubfix == null) {
			packageSubfix = Constant.PACKAGE_SUBFIX.get(getType());
		}
		if (packageSubfix == null) {
			throw new RuntimeException("should suply either method getPackageSubfix() or getType() and config the PACKAGE_SUBFIX constant");
		}
		String appBasePackage = ApplicationContext.getInstance().getAppBasePackage();
		return appBasePackage  + "."+ packageSubfix;
	}

	public abstract String getType();

	public String getDestFilePath(String packageName, String name) {
		return getDestPathPrefix() + Util.packageToFolder(packageName) + "/" + name + ".java";
	}

	public String getDestPathPrefix() {
		return ApplicationContext.getInstance().getConfigContext().getDestPathPrefix();
	}

	public String getNameSubfix() {
		return null;
	}
	
	public String getNamePrefix() {
		return "";
	}

	public String getPackageSubfix() {
		return null;
	}
	
	@Override
	public boolean needRegist(ModelWrapper model) {
		
		return true;
	}
}
