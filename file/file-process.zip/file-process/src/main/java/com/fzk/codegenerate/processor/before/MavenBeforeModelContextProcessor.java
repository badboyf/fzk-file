package com.fzk.codegenerate.processor.before;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.fzk.codegenerate.context.ApplicationContext;
import com.fzk.codegenerate.processor.BeforeApplicationProcessor;

public class MavenBeforeModelContextProcessor implements BeforeApplicationProcessor {

	@Override
	public void process() {
		try {
			String project = ApplicationContext.getInstance().getConfigContext().getProject();
			mavenBuild(project);
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public static void mavenBuild(String path) throws IOException {
		Process process = Runtime.getRuntime().exec("cmd.exe /c cd /d " + path + " && mvn package");
		BufferedReader br = null;
		br = new BufferedReader(new InputStreamReader(process.getInputStream(), "GBK"));
		String line = null;
		while ((line = br.readLine()) != null) {
			System.out.println(line);
		}
	}

	@Override
	public int getOrder() {

		return 0;
	}
}
