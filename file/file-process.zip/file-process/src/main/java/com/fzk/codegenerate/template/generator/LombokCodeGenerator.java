package com.fzk.codegenerate.template.generator;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.Map;

import com.fzk.codegenerate.definition.Definition;
import com.fzk.codegenerate.template.LombokTemplatePath;
import com.fzk.codegenerate.template.LombokValueTemplateParser;
import com.fzk.codegenerate.template.TemplatePath;
import com.fzk.codegenerate.template.TemplateProcessor;
import com.fzk.codegenerate.template.impl.DefaultTemplateProcessor;

public class LombokCodeGenerator implements CodeGenerator{
	private TemplatePath templatePath;
	private LombokValueTemplateParser templateParser;
	TemplateProcessor templateProcessor = new DefaultTemplateProcessor();
	private boolean override = false;

	public LombokCodeGenerator(TemplatePath templatePath, LombokValueTemplateParser templateParser, boolean override) {
		this.templatePath = templatePath;
		this.templateParser = templateParser;
		this.override = override;
	}

	public LombokCodeGenerator(TemplatePath templatePath, LombokValueTemplateParser templateParser, TemplateProcessor templateProcessor,
			boolean override) {
		this(templatePath, templateParser, override);
		this.templateProcessor = templateProcessor;
	}

	public LombokCodeGenerator() {
		this(new LombokTemplatePath(), new LombokValueTemplateParser(), new DefaultTemplateProcessor(), true);
	}

	@Override
	public void generate(Definition definition) throws Exception {
		String tmpPath = templatePath.getPath(definition);
		String filePath = definition.getDestFilePath();
		System.out.println("dest path:" + filePath);
		Map<String, Object> value = templateParser.parse(definition);
		String data = templateProcessor.process(tmpPath, value);

		File file = new File(filePath);

		if (!file.getParentFile().exists()) {
			file.getParentFile().mkdirs();
		}

		if (file.exists() && !override) {
			System.out.println("file exist, pass");
		}

		FileWriter fw = new FileWriter(filePath);
		BufferedWriter bw = new BufferedWriter(fw);

		try {
			bw.write(data);
			bw.flush();
		} catch (Exception e) {
			if (fw != null) {
				fw.close();
			}
			if (bw != null) {
				bw.close();
			}
		}
	}

}
