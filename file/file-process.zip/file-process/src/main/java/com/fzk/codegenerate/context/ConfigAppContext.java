package com.fzk.codegenerate.context;

import java.net.URLClassLoader;
import java.util.List;

import com.fzk.codegenerate.util.Constant;

import lombok.Data;

@Data
public class ConfigAppContext {
	public static URLClassLoader CLASS_LOADER = (URLClassLoader) ClassLoader.getSystemClassLoader();

	private String destPathPrefix;
	private String securityDestPathPrefix;
	private String apiDestPathPrefix;
	private String eventDestPathPrefix;
	private String project;
	private String basePackage = "com.crossdomain";
	private String modelPackage = "domain.model";
	private List<String> crdTypes = Constant.CRD_TYPES;
	private Boolean isSearch = false;
	private String processModel;

	public ConfigAppContext() {

	}

	public ConfigAppContext isSearch() {
		this.modelPackage = "search.model";
		this.isSearch = true;
		return this;
	}

	public ConfigAppContext basePackage(String basePackage) {
		this.basePackage = basePackage;
		return this;
	}

	public ConfigAppContext modelPackage(String modelPackage) {
		this.modelPackage = modelPackage;
		return this;
	}

	public ConfigAppContext destPathPrefix(String destPathPrefix) {
		destPathPrefix = destPathPrefix.replace("\\", "/");
		this.destPathPrefix = destPathPrefix;
		return this;
	}

	public ConfigAppContext eventDestPathPrefix(String eventDestPathPrefix) {
		eventDestPathPrefix = eventDestPathPrefix.replace("\\", "/");
		this.eventDestPathPrefix = eventDestPathPrefix;
		return this;
	}

	public ConfigAppContext apiDestPathPrefix(String apiDestPathPrefix) {
		apiDestPathPrefix = apiDestPathPrefix.replace("\\", "/");
		this.apiDestPathPrefix = apiDestPathPrefix;
		return this;
	}

	public ConfigAppContext project(String project) {
		project = project.replace("\\", "/");
		this.project = project;
		return this;
	}

	public ConfigAppContext securityDestPathPrefix(String securityDestPathPrefix) {
		if (securityDestPathPrefix == null) {
			return this;
		}
		securityDestPathPrefix = securityDestPathPrefix.replace("\\", "/");
		this.securityDestPathPrefix = securityDestPathPrefix;
		return this;
	}

	public ConfigAppContext crdTypes(List<String> crdTypes) {
		this.crdTypes = crdTypes;
		return this;
	}

	public ConfigAppContext processModel(String processModel) {
		this.processModel = processModel;
		return this;
	}
	
	public String getProcessModel(){
		return processModel;
	}
}
