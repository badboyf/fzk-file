package com.fzk.codegenerate.registry.impl;

import com.fzk.codegenerate.definition.CommonDefinition;
import com.fzk.codegenerate.definition.Definition;
import com.fzk.codegenerate.registry.AbstractSingleDefinitionRegistry;
import com.fzk.codegenerate.util.Constant;
import com.fzk.codegenerate.wrapper.ModelWrapper;

public class RepositoryDefinitionRegistry extends AbstractSingleDefinitionRegistry {

	@Override
	public Definition getDefinition(ModelWrapper model) {
		String name = getName(model);
		String packageName = getPackageName(model);
		Class<?> baseClass = model.getBaseClass();
		String destFilePath = getDestFilePath(packageName, name);
		String type = getType();
		Definition definition = new CommonDefinition(name, packageName, baseClass, destFilePath, type);

		return definition;
	}

	@Override
	public String getType() {

		return Constant.TYPE_REPOSITORY;
	}

	@Override
	public boolean needRegist(ModelWrapper model) {

		return model.getType() == ModelWrapper.Type.MODEL;
	}
}
