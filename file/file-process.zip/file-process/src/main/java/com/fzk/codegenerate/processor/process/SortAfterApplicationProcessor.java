package com.fzk.codegenerate.processor.process;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.fzk.codegenerate.definition.Definition;
import com.fzk.codegenerate.processor.AfterApplicationProcessor;

public class SortAfterApplicationProcessor implements AfterApplicationProcessor {

	@Override
	public void process(List<Definition> definitions) {
		Collections.sort(definitions, new Comparator<Definition>() {

			@Override
			public int compare(Definition o1, Definition o2) {

				return o1.getPackageName().compareTo(o2.getPackageName());
			}
		});
	}

	@Override
	public int getOrder() {

		return 0;
	}

}
