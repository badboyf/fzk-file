package com.fzk.codegenerate.template;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import org.springframework.data.annotation.Id;

import com.fzk.codegenerate.context.ModelHolder;
import com.fzk.codegenerate.definition.Definition;
import com.fzk.codegenerate.definition.TypeCommonDefinition;
import com.fzk.codegenerate.util.Constant;
import com.fzk.codegenerate.util.Util;

public class DefinitionValueTemplateParser {

	public Map<String, Object> parse(Definition definition) {
		Map<String, Object> map = new HashMap<String, Object>();

		switch (definition.getDefinitionType()) {
		case Constant.TYPE_ASSEMBLE:
			map = assemble(definition);
			break;
		case Constant.TYPE_EVENT_CONSTANT:
			map = constant(definition);
			break;
		case Constant.TYPE_CRUD_REPOSITORY:
			map = curdRepository(definition);
			break;
		case Constant.TYPE_DTO:
			map = dto(definition);
			break;
		case Constant.TYPE_EVENT:
			map = event(definition);
			break;
		case Constant.TYPE_EVENT_VO:
			map = eventVo(definition);
			break;
		case Constant.TYPE_FACTORY:
			map = factory(definition);
			break;
		case Constant.TYPE_ISERVICE:
			map = iservice(definition);
			break;
		case Constant.TYPE_REPOSITORY:
			map = repository(definition);
			break;
		case Constant.TYPE_RESOLVER:
			map = resolver(definition);
			break;
		case Constant.TYPE_SERVICE:
			map = service(definition);
			break;
		default:
			break;
		}

		return map;
	}
	
	public Map<String, Object> resolver(Definition definition) {
		TypeCommonDefinition typeDefinition = (TypeCommonDefinition) definition;
		Map<String, Object> map = new HashMap<String, Object>();
		ModelHolder modelHolder = ModelHolder.getInstance();

		List<String> imports = new ArrayList<String>();
		imports.add("org.springframework.stereotype.Component");
		imports.add("com.crossdomain.common.domain.event.message.EventMessageResolver");
		imports.add("com.crossdomain.common.infrastructure.mq.message.MQMessage");

		Definition constantD = modelHolder.get(definition.getBaseClass().getName(), Constant.TYPE_EVENT_CONSTANT);
		String constant = constantD.getName();
		imports.add(constantD.getPackageName() + "." + constantD.getName());
		
		String key = constantD.getBaseClass().getSimpleName().toUpperCase() + "_" + typeDefinition.getType().toUpperCase() + "_KEY";
		String tag = constantD.getBaseClass().getSimpleName().toUpperCase() + "_" + typeDefinition.getType().toUpperCase() + "_TAG";
		String topic = constantD.getBaseClass().getSimpleName().toUpperCase() + "_" + typeDefinition.getType().toUpperCase() + "_TOPIC";

		Definition eventD = modelHolder.get(definition.getBaseClass().getName(), Constant.TYPE_EVENT);
		String event = eventD.getName();
		imports.add(eventD.getPackageName() + "." + eventD.getName());

		List<String> importResults = new ArrayList<>();
		for (String tmp : imports) {
			importResults.add("import " + tmp + ";");
		}

		map.put("classname", definition.getName());
		map.put("package", definition.getPackageName());
		map.put("event", event);
		map.put("constant", constant);
		map.put("key", key);
		map.put("tag", tag);
		map.put("topic", topic);
		map.put("import", importResults);
		map.put("date", Util.now());
		
		return map;
	}
	
	public Map<String, Object> service(Definition definition) {
		Map<String, Object> map = new HashMap<String, Object>();
		ModelHolder modelHolder = ModelHolder.getInstance();

		List<String> imports = new ArrayList<String>();
		imports.add("com.alibaba.dubbo.config.annotation.Service");
		imports.add("org.springframework.web.bind.annotation.RestController");
		imports.add("org.springframework.beans.factory.annotation.Autowired");
		imports.add("org.springframework.web.bind.annotation.RequestBody");
		imports.add("org.springframework.web.bind.annotation.PathVariable");
		imports.add("io.swagger.annotations.ApiParam");
		imports.add(definition.getBaseClass().getName());

		String srcName = Util.firstLower(definition.getBaseClass().getSimpleName()) + "DTO";
		String path = definition.getBaseClass().getSimpleName().toLowerCase();

		Definition iServiceDefinition = modelHolder.get(definition.getBaseClass().getName(), Constant.TYPE_ISERVICE);
		String interfaceName = iServiceDefinition.getName();
		imports.add(iServiceDefinition.getPackageName() + "." + iServiceDefinition.getName());

		Definition dtoDefinition = modelHolder.get(definition.getBaseClass().getName(), Constant.TYPE_DTO);
		imports.add(dtoDefinition.getPackageName() + "." + dtoDefinition.getName());
		String srcType = dtoDefinition.getName();

		Definition assembleD = modelHolder.get(definition.getBaseClass().getName(), Constant.TYPE_ASSEMBLE);
		imports.add(assembleD.getPackageName() + "." + assembleD.getName());
		String assembleType = assembleD.getName();
		String assemble = Util.firstLower(assembleType);

		Definition factoryD = modelHolder.get(definition.getBaseClass().getName(), Constant.TYPE_FACTORY);
		imports.add(factoryD.getPackageName() + "." + factoryD.getName());
		String factoryType = factoryD.getName();
		String factory = Util.firstLower(factoryType);

		Definition reposirotyD = modelHolder.get(definition.getBaseClass().getName(), Constant.TYPE_REPOSITORY);
		imports.add(reposirotyD.getPackageName() + "." + reposirotyD.getName());
		String repositoryType = reposirotyD.getName();
		String repository = Util.firstLower(repositoryType);

		String modelType = definition.getBaseClass().getSimpleName();
		String modelName = Util.firstLower(modelType);

		String id = "";
		String idType = "";
		for (Field field : definition.getBaseClass().getDeclaredFields()) {
			if (Modifier.toString(field.getModifiers()).contains("static")) {
				continue;
			}
			id = field.getName();
			idType = field.getType().getSimpleName();
			break;
		}

		List<String> importResults = new ArrayList<>();
		for (String tmp : imports) {
			importResults.add("import " + tmp + ";");
		}

		map.put("classname", definition.getName());
		map.put("package", definition.getPackageName());
		map.put("import", importResults);
		map.put("date", Util.now());
		map.put("srcType", srcType);
		map.put("srcName", srcName);
		map.put("path", path);
		map.put("id", id);
		map.put("idType", idType);
		map.put("interface", interfaceName);
		map.put("assembleType", assembleType);
		map.put("assemble", assemble);
		map.put("factoryType", factoryType);
		map.put("factory", factory);
		map.put("repositoryType", repositoryType);
		map.put("repository", repository);
		map.put("modelType", modelType);
		map.put("modelName", modelName);

		return map;
	}
	
	public Map<String, Object> repository(Definition definition) {
		Map<String, Object> map = new HashMap<String, Object>();
		ModelHolder modelHolder = ModelHolder.getInstance();

		String extendClassname = "";
		String imports = "";
		Definition crud = modelHolder.get(definition.getBaseClass().getName(), Constant.TYPE_CRUD_REPOSITORY);
		if (crud != null) {
			extendClassname = crud.getName();
			imports = "import " + crud.getPackageName() + "." + crud.getName() + ";";
		}

		map.put("classname", definition.getName());
		map.put("package", definition.getPackageName());
		map.put("extend_classname", extendClassname);
		map.put("import", imports);
		map.put("date", Util.now());

		return map;
	}
	
	public Map<String, Object> iservice(Definition definition) {
		Map<String, Object> map = new HashMap<String, Object>();
		ModelHolder modelHolder = ModelHolder.getInstance();

		List<String> imports = new ArrayList<String>();

		String srcName = Util.firstLower(definition.getBaseClass().getSimpleName());
		String path = srcName.toLowerCase();

		Definition dtoDefinition = modelHolder.get(definition.getBaseClass().getName(), Constant.TYPE_DTO);
		imports.add(dtoDefinition.getPackageName() + "." + dtoDefinition.getName());
		String srcType = dtoDefinition.getName();

		String id = "";
		String idType = "";
		for (Field field : definition.getBaseClass().getDeclaredFields()) {
			if (Modifier.toString(field.getModifiers()).contains("static")) {
				continue;
			}
			id = field.getName();
			idType = field.getType().getSimpleName();
			break;
		}

		List<String> importResults = new ArrayList<>();
		for (String tmp : imports) {
			importResults.add("import " + tmp + ";");
		}

		map.put("classname", definition.getName());
		map.put("package", definition.getPackageName());
		map.put("import", importResults);
		map.put("date", Util.now());
		map.put("srcType", srcType);
		map.put("srcName", srcName);
		map.put("path", path);
		map.put("id", id);
		map.put("idType", idType);

		return map;
	}
	
	public Map<String, Object> factory(Definition definition) {
		Map<String, Object> map = new HashMap<String, Object>();
		ModelHolder modelHolder = ModelHolder.getInstance();

		List<String> importsTmp = new ArrayList<String>();
		List<String> autowireds = new ArrayList<String>();
		List<String> genFields = new ArrayList<String>();
		String constructorFields = "";

		String destType = definition.getBaseClass().getSimpleName();
		String srcType = destType + Constant.DTO;
		String srcName = Util.firstLower(srcType);
		String srcNames = srcName + "s";

		importsTmp.add("java.util.List");
		importsTmp.add("java.util.ArrayList");
		importsTmp.add("org.springframework.stereotype.Component");
		importsTmp.add(definition.getBaseClass().getName());
		Definition dtoDefinition = modelHolder.get(definition.getBaseClass().getName(), Constant.TYPE_DTO);
		importsTmp.add(dtoDefinition.getPackageName() + "." + dtoDefinition.getName());

		List<Field> fields = new ArrayList<>();
		for (Field field : definition.getBaseClass().getDeclaredFields()) {
			if (Modifier.toString(field.getModifiers()).contains("static")) {
				continue;
			}
			fields.add(field);
		}

		if (definition.getBaseClass().isEnum()) {
			String method = null;
			if (!fields.isEmpty()) {
				method = "get" + Util.firstUpper(fields.get(0).getName()) + "()";
			}
			map.put("method", method);
		} else {
			importsTmp.add("org.springframework.util.CollectionUtils");

			for (int i = 0, size = fields.size(); i < size; i++) {
				Field field = fields.get(i);

				String showType = field.getType().getSimpleName();
				String showName = field.getName().equalsIgnoreCase(definition.getBaseClass().getSimpleName()) ? field.getName() : field.getName() + "Tmp";
				String genFieldSubfix = srcName + ".get" + Util.firstUpper(field.getName()) + "()";

				Class<?> type = field.getType();

				if (modelHolder.allBaseClass().contains(type)) {
					if (!importsTmp.contains(type.getName())) {
						importsTmp.add(type.getName());
					}
					Util.addAutowired(field.getType().getName(), autowireds, Constant.TYPE_FACTORY);
//					Util.addAutowireFactory(field.getType().getSimpleName(), autowireds);
					genFieldSubfix = Util.firstLower(field.getType().getSimpleName()) + Constant.FACTORY + ".factory(" + genFieldSubfix + ");";
				} else {
					if (!importsTmp.contains(type.getName())) {
						importsTmp.add(type.getName());
					}
					Type genericSuperclass = field.getGenericType();
					String typeSimpleName = null;
					if (genericSuperclass instanceof ParameterizedType) {
						Type[] types = ((ParameterizedType) field.getGenericType()).getActualTypeArguments();
						for (int index = 0, typeSize = types.length; index < typeSize; index++) {
							Type t = types[index];
							String typeName = t.getTypeName();
							String simpleName = typeName.substring(typeName.lastIndexOf(".") + 1);
							typeSimpleName = simpleName;
							if (index == 0) {
								showType += "<" + simpleName;
							}
							if (index > 0 && index < typeSize - 1) {
								showType += ", " + simpleName;
							}
							if (index == typeSize - 1) {
								showType += ">";
							}
							if (modelHolder.containsType(typeName)) {
								if (!importsTmp.contains(typeName)) {
									importsTmp.add(typeName);
								}
								Util.addAutowired(typeName, autowireds, Constant.TYPE_FACTORY);
//								Util.addAutowireFactory(simpleName, autowireds);
							}
						}
					}
					if (field.getType() == List.class || field.getType() == Set.class) {
						if (typeSimpleName != null && modelHolder.containsType(typeSimpleName)) {
							genFieldSubfix = Util.firstLower(typeSimpleName) + Constant.FACTORY + ".factory(" + genFieldSubfix + ");";
						} else {
							genFieldSubfix = genFieldSubfix + ";";
						}
					} else {
						genFieldSubfix = genFieldSubfix + ";";
					}
				}
				StringBuffer genField = new StringBuffer();
				genField.append("		");
				genField.append(showType);
				genField.append(" ");
				genField.append(showName);
				genField.append(" = ");
				genField.append(genFieldSubfix);
				genFields.add(genField.toString());

				String constructorField = showName;
				constructorField += (i == size - 1) ? "" : ", ";
				constructorFields += constructorField;
			}
			map.put("constructor_fields", constructorFields);
			map.put("gen_fields", genFields);
			map.put("autowired", autowireds);
		}

		if (!autowireds.isEmpty()) {
			importsTmp.add("org.springframework.beans.factory.annotation.Autowired");
		}

		Collections.sort(importsTmp);
		List<String> imports = new ArrayList<>();
		for (String tmp : importsTmp) {
			imports.add("import " + tmp + ";");
		}

		map.put("classname", definition.getName());
		map.put("package", definition.getPackageName());
		map.put("srcType", srcType);
		map.put("srcName", srcName);
		map.put("srcNames", srcNames);
		map.put("destType", destType);
		map.put("import", imports);
		map.put("date", Util.now());

		return map;
	}

	
	private Map<String, Object> assemble(Definition definition) {
			Map<String, Object> map = new HashMap<String, Object>();
			ModelHolder modelHolder = ModelHolder.getInstance();

			List<String> imports = new ArrayList<String>();
			List<String> autowireds = new ArrayList<String>();
			List<String> genFields = new ArrayList<String>();
			String constructorFields = "";

			String srcType = definition.getBaseClass().getSimpleName();
			String descType = srcType + Constant.DTO;
			String srcName = Util.firstLower(definition.getBaseClass().getSimpleName());
			String srcNames = srcName + "s";

			imports.add("java.util.ArrayList");
			imports.add("java.util.List");
			imports.add(definition.getBaseClass().getName());
			
			Definition dtoDefinition = modelHolder.get(definition.getBaseClass().getName(), Constant.TYPE_DTO);
			imports.add(dtoDefinition.getPackageName() + "." + dtoDefinition.getName());

			List<Field> fields = new ArrayList<>();
			for (Field field : definition.getBaseClass().getDeclaredFields()) {
				if (Modifier.toString(field.getModifiers()).contains("static")) {
					continue;
				}
				fields.add(field);
			}

			for (int i = 0, size = fields.size(); i < size; i++) {
				Field field = fields.get(i);

				String showType = field.getType().getSimpleName();
				String showName = field.getName().equalsIgnoreCase(definition.getBaseClass().getSimpleName())
						? field.getName() + field.getType().getSimpleName()
						: field.getName();
				String genFieldSubfix = srcName + ".get" + Util.firstUpper(field.getName()) + "()";

				Class<?> type = field.getType();

				if (ModelHolder.getInstance().allBaseClass().contains(type)) {
					Definition dto = modelHolder.get(type.getName(), Constant.TYPE_DTO);
					if (dto != null) {
						imports.add(dto.getPackageName() + "." + dto.getName());
					}
					showType += Constant.DTO;
					Util.addAutowired(field.getType().getName(), autowireds, Constant.TYPE_ASSEMBLE);
//					Util.addAutowireAssemble(field.getType().getSimpleName(), autowireds);
					genFieldSubfix = Util.firstLower(field.getType().getSimpleName()) + Constant.ASSEMBLE + ".assemble(" + genFieldSubfix + ");";
				} else {
					if (!imports.contains(type.getName())) {
						imports.add(type.getName());
					}
					Type genericSuperclass = field.getGenericType();
					String typeSimpleName = null;
					if (genericSuperclass instanceof ParameterizedType) {
						Type[] types = ((ParameterizedType) field.getGenericType()).getActualTypeArguments();
						for (int index = 0, typeSize = types.length; index < typeSize; index++) {
							Type t = types[index];
							String typeName = t.getTypeName();
							String simpleName = typeName.substring(typeName.lastIndexOf(".") + 1);
							typeSimpleName = simpleName;
							if (index == 0) {
								showType += "<" + simpleName;
								if (modelHolder.containsType(typeName)) {
									showType += Constant.DTO;
								}
							}
							if (index > 0 || index < typeSize - 1) {
								showType += ", " + simpleName;
								if (modelHolder.containsType(typeName)) {
									showType += Constant.DTO;
								}
							}
							if (index == typeSize - 1) {
								showType += ">";
							}
							if (modelHolder.containsType(typeName)) {
								Definition dto = modelHolder.get(typeName, Constant.TYPE_DTO);
								String dtoImport = dto.getPackageName() + "." + dto.getName();
								if (!imports.contains(dtoImport)) {
									imports.add(dtoImport);
								}
								Util.addAutowired(typeName, autowireds, Constant.TYPE_ASSEMBLE);
//								Util.addAutowireAssemble(simpleName, autowireds);
							}
						}
					}
					if (field.getType() == List.class || field.getType() == Set.class) {
						if (typeSimpleName != null && modelHolder.containsType(typeSimpleName)) {
							genFieldSubfix = Util.firstLower(typeSimpleName) + Constant.ASSEMBLE + ".assemble(" + genFieldSubfix + ");";
						} else {
							genFieldSubfix = genFieldSubfix + ";";
						}
					} else {
						genFieldSubfix = genFieldSubfix + ";";
					}
				}

				StringBuffer genField = new StringBuffer();
				genField.append(showType);
				genField.append(" ");
				genField.append(showName);
				genField.append(" = ");
				genField.append(genFieldSubfix);
				genFields.add("		" + genField.toString());

				String constructorField = showName;
				constructorField += (i == size - 1) ? "" : ", ";
				constructorFields += constructorField;
			}

			if (autowireds.size() > 0) {
				imports.add("org.springframework.beans.factory.annotation.Autowired");
			}

			imports.remove("java.util.ArrayList");
			imports.remove("java.util.List");
			List<String> importResults = new ArrayList<>();
			for (String tmp : imports) {
				importResults.add("import " + tmp + ";");
			}

			map.put("classname", definition.getName());
			map.put("package", definition.getPackageName());
			map.put("srcType", srcType);
			map.put("srcName", srcName);
			map.put("srcNames", srcNames);
			map.put("descType", descType);
			map.put("constructor_fields", constructorFields);
			map.put("gen_fields", genFields);
			map.put("autowired", autowireds);
			map.put("import", importResults);
			map.put("date", Util.now());
			
			return map;
	}
	
	public Map<String, Object> constant(Definition definition) {
		Map<String, Object> map = new HashMap<String, Object>();

		String constantPrefix = definition.getBaseClass().getSimpleName().toUpperCase();
		String topicPrefix = definition.getBaseClass().getSimpleName().toLowerCase();
		String resolverPrefix = definition.getBaseClass().getSimpleName();

		map.put("classname", definition.getName());
		map.put("package", definition.getPackageName());
		map.put("date", Util.now());
		map.put("constant_prefix", constantPrefix);
		map.put("topic_prefix", topicPrefix);
		map.put("resolver_prefix", resolverPrefix);
		return map;
	}
	
	public Map<String, Object> curdRepository(Definition definition) {
		Map<String, Object> map = new HashMap<String, Object>();

		String importPackage = "import " + definition.getBaseClass().getName() + ";";
		String srcType = definition.getBaseClass().getSimpleName();
		String idType = null;
		String getIdMethods = null;

		List<Field> fields = new ArrayList<>();
		for (Field field : definition.getBaseClass().getDeclaredFields()) {
			if (Modifier.toString(field.getModifiers()).contains("static")) {
				continue;
			}
			fields.add(field);
		}

		for (int i = 0, size = fields.size(); i < size; i++) {
			Field field = fields.get(i);
			if (Modifier.toString(field.getModifiers()).contains("static")) {
				continue;
			}

//			if (i == 0) {
			if (field.isAnnotationPresent(Id.class)) {
				idType = field.getType().getSimpleName();
				String fieldName = field.getName();
				getIdMethods = "get" + Util.firstUpper(fieldName) + "()";
			}
		}

		map.put("classname", definition.getName());
		map.put("package", definition.getPackageName());
		map.put("srcType", srcType);
		map.put("idType", idType);
		map.put("get_id_method", getIdMethods);
		map.put("import", importPackage);
		map.put("date", Util.now());

		return map;
	}

	public Map<String, Object> dto(Definition definition) {
		Map<String, Object> map = new HashMap<String, Object>();
		ModelHolder modelHolder = ModelHolder.getInstance();

		List<String> imports = new ArrayList<String>();
		List<String> constructorFields = new ArrayList<String>();
		List<String> methods = new ArrayList<String>();
		List<String> dtoFields = new ArrayList<String>();
		StringBuffer constractorParams = new StringBuffer();

		List<Field> fields = new ArrayList<>();
		for (Field field : definition.getBaseClass().getDeclaredFields()) {
			if (Modifier.toString(field.getModifiers()).contains("static")) {
				continue;
			}
			fields.add(field);
		}

		for (int i = 0, size = fields.size(); i < size; i++) {
			Field field = fields.get(i);
			String showType = field.getType().getSimpleName();
			String method = "get" + Util.firstUpper(field.getName()) + "()";

			Class<?> type = field.getType();
			if (!imports.contains(type.getName())) {
				imports.add(type.getName());
			}

			if (modelHolder.allBaseClass().contains(type)) {
				showType += Constant.DTO;
			} else {
				Type genericSuperclass = field.getGenericType();
				if (genericSuperclass instanceof ParameterizedType) {
					Type[] types = ((ParameterizedType) field.getGenericType()).getActualTypeArguments();
					for (int index = 0, typeSize = types.length; index < typeSize; index++) {
						Type t = types[index];
						String typeName = t.getTypeName();
						String simpleName = typeName.substring(typeName.lastIndexOf(".") + 1);
						if (modelHolder.containsType(typeName)) {
							simpleName += Constant.DTO;
						}
						if (index == 0) {
							showType += "<" + simpleName;
						}
						if (index > 0 && index < typeSize - 1) {
							showType += ", " + simpleName;
						}
						if (index == typeSize - 1) {
							showType += ">";
						}
						if (modelHolder.containsType(typeName)) {
							if (!imports.contains(typeName)) {
								imports.add(typeName);
							}
						}
					}
				}
			}

			constructorFields.add("		this." + field.getName() + " = " + field.getName() + ";");

			dtoFields.add("    @ApiModelProperty(notes = \"\", required = false)");
			dtoFields.add("    private " + showType + " " + field.getName() + ";");
			dtoFields.add("");

			constractorParams.append(showType + " " + field.getName() + (i == size - 1 ? "" : ", "));

			methods.add("	public " + showType + " " + method + " {");
			methods.add("		return this." + field.getName() + ";");
			methods.add("	}");
			methods.add("");
		}

		List<String> importResults = new ArrayList<>();
		for (String tmp : imports) {
			if (!modelHolder.containsType(tmp)) {
				importResults.add("import " + tmp + ";");
			}
		}

		map.put("serialVersionUID", String.valueOf(new Random().nextInt(Integer.MAX_VALUE)));
		map.put("classname", definition.getName());
		map.put("package", Util.getPackage(definition.getPackageName()));
		map.put("imports", importResults);
		map.put("fields", dtoFields);
		map.put("constractor_params", constractorParams.toString());
		map.put("constractor_fields", constructorFields);
		map.put("getMethods", methods);
		map.put("date", Util.now());
		
		return map;
	}
	
	public Map<String, Object> event(Definition definition) {
		Map<String, Object> map = new HashMap<String, Object>();
		ModelHolder modelHolder = ModelHolder.getInstance();

		List<String> imports = new ArrayList<String>();
		List<String> constructorFields = new ArrayList<String>();
		List<String> methods = new ArrayList<String>();
		List<String> eventVoFields = new ArrayList<String>();
		StringBuffer constractorParams = new StringBuffer();

		List<Field> fields = new ArrayList<>();
		for (Field field : definition.getBaseClass().getDeclaredFields()) {
			if (Modifier.toString(field.getModifiers()).contains("static")) {
				continue;
			}
			fields.add(field);
		}

		for (int i = 0, size = fields.size(); i < size; i++) {
			Field field = fields.get(i);
			Definition eventVo = modelHolder.get(field.getType().getName(), Constant.TYPE_EVENT_VO);

			String showType = "";
			String method = "get" + Util.firstUpper(field.getName()) + "()";

			if (eventVo != null) {
				showType = eventVo.getName();
				String eventVoType = eventVo.getPackageName() + "." + eventVo.getName();
				if (!imports.contains(eventVoType)) {
					imports.add(eventVoType);
				}
			} else {
				Class<?> type = field.getType();
				if (!imports.contains(type.getName())) {
					imports.add(type.getName());
				}
				showType = field.getType().getSimpleName();

				Type genericSuperclass = field.getGenericType();
				if (genericSuperclass instanceof ParameterizedType) {
					Type[] types = ((ParameterizedType) field.getGenericType()).getActualTypeArguments();
					for (int index = 0, typeSize = types.length; index < typeSize; index++) {
						Type t = types[index];
						Definition genericEventVo = modelHolder.get(t.getTypeName(), Constant.TYPE_EVENT_VO);
						String typeName = "";
						String simpleName = "";
						if (genericEventVo == null) {
							typeName = t.getTypeName();
							simpleName = t.getTypeName().substring(t.getTypeName().lastIndexOf(".") + 1);
						} else {
							typeName = genericEventVo.getPackageName() + "." + genericEventVo.getName();
							simpleName = genericEventVo.getName();
						}
						if (index == 0) {
							showType += "<" + simpleName;
						}
						if (index > 0 && index < typeSize - 1) {
							showType += ", " + simpleName;
						}
						if (index == typeSize - 1) {
							showType += ">";
						}
						if (!imports.contains(typeName)) {
							imports.add(typeName);
						}
					}
				}
			}

			constructorFields.add("		this." + field.getName() + " = " + field.getName() + ";");
			eventVoFields.add("    private " + showType + " " + field.getName() + ";");

			constractorParams.append(showType + " " + field.getName() + (i == size - 1 ? "" : ", "));

			methods.add("	public " + showType + " " + method + " {");
			methods.add("		return this." + field.getName() + ";");
			methods.add("	}");
			methods.add("");
		}

		List<String> importResults = new ArrayList<>();
		for (String tmp : imports) {
			importResults.add("import " + tmp + ";");
		}

		map.put("serialVersionUID", String.valueOf(new Random().nextInt(Integer.MAX_VALUE)));
		map.put("classname", definition.getName());
		map.put("package", definition.getPackageName());
		map.put("import", importResults);
		map.put("fields", eventVoFields);
		map.put("constractor_params", constractorParams.toString());
		map.put("constractor_fields", constructorFields);
		map.put("methods", methods);
		map.put("date", Util.now());

		return map;
	}
	
	public Map<String, Object> eventVo(Definition definition) {
		Map<String, Object> map = new HashMap<String, Object>();
		ModelHolder modelHolder = ModelHolder.getInstance();

		List<String> imports = new ArrayList<String>();
		List<String> constructorFields = new ArrayList<String>();
		StringBuffer constractorParams = new StringBuffer();
		List<String> methods = new ArrayList<String>();
		List<String> eventVoFields = new ArrayList<String>();

		List<Field> fields = new ArrayList<>();
		for (Field field : definition.getBaseClass().getDeclaredFields()) {
			if (Modifier.toString(field.getModifiers()).contains("static")) {
				continue;
			}
			fields.add(field);
		}

		for (int i = 0, size = fields.size(); i < size; i++) {
			Field field = fields.get(i);
			Definition eventVo = modelHolder.get(field.getType().getName(), Constant.TYPE_EVENT_VO);

			String showType = "";
			String method = "get" + Util.firstUpper(field.getName()) + "()";

			Class<?> type = field.getType();
			if (!imports.contains(type.getName())) {
				imports.add(type.getName());
			}

			if (eventVo != null) {
				showType = eventVo.getName();
			} else {
				showType = field.getType().getSimpleName();

				Type genericSuperclass = field.getGenericType();
				if (genericSuperclass instanceof ParameterizedType) {
					Type[] types = ((ParameterizedType) field.getGenericType()).getActualTypeArguments();
					for (int index = 0, typeSize = types.length; index < typeSize; index++) {
						Type t = types[index];
						Definition genericEventVo = modelHolder.get(t.getTypeName(), Constant.TYPE_EVENT_VO);
						String typeName = "";
						String simpleName = "";
						if (genericEventVo == null) {
							typeName = t.getTypeName();
							simpleName = t.getTypeName().substring(t.getTypeName().lastIndexOf(".") + 1);
						} else {
							typeName = genericEventVo.getPackageName() + "." + genericEventVo.getName();
							simpleName = genericEventVo.getName();
						}
						if (index == 0) {
							showType += "<" + simpleName;
						}
						if (index > 0 && index < typeSize - 1) {
							showType += ", " + simpleName;
						}
						if (index == typeSize - 1) {
							showType += ">";
						}
						if (!imports.contains(typeName)) {
							imports.add(typeName);
						}
					}
				}
			}

			constructorFields.add("		this." + field.getName() + " = " + field.getName() + ";");
			eventVoFields.add("    private " + showType + " " + field.getName() + ";");

			constractorParams.append(showType + " " + field.getName() + (i == size - 1 ? "" : ", "));

			methods.add("	public " + showType + " " + method + " {");
			methods.add("		return this." + field.getName() + ";");
			methods.add("	}");
			methods.add("");
		}

		List<String> importResults = new ArrayList<>();
		for (String tmp : imports) {
			if (!modelHolder.containsType(tmp)) {
				importResults.add("import " + tmp + ";");
			}
		}

		map.put("serialVersionUID", String.valueOf(new Random().nextInt(Integer.MAX_VALUE)));
		map.put("classname", definition.getName());
		map.put("package", definition.getPackageName());
		map.put("import", importResults);
		map.put("fields", eventVoFields);
		map.put("constractor_params", constractorParams.toString());
		map.put("constractor_fields", constructorFields);
		map.put("methods", methods);
		map.put("date", Util.now());
		map.put("date", Util.now());

		return map;
	}
}
