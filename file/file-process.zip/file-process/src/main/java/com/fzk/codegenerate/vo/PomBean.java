/*
 * @Title : Pom.java
 * 
 * @version V1.0
 * @date：2019年1月15日
 * @Copyright © 2019 江苏华叶跨域教育科技发展股份有限公司 Corporation. All rights reserved. 
 */
package com.fzk.codegenerate.vo;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/** 
 * @ClassName: Pom 
 * @Description: 
 * @author fengzhikui
 * @date 2019年1月15日 
 *  
 */
public class PomBean {

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@EqualsAndHashCode(callSuper=false)
	public static class Pom extends PomBase {
		PomBase parent;
		Dependencies dependencies;
		DependencyManagement dependencyManagement;
	}
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@EqualsAndHashCode(callSuper=false)
	public static class PomBase {
		public static final String GROUP_ID = "groupId";
		public static final String ARTIFACT_ID = "artifactId";
		public static final String VERSION = "version";
		String groupId;
		String artifactId;
		String version;
		String scope;
		String type;
		public void set(String key, String value) throws Exception {
			try {
				Field field = this.getClass().getDeclaredField(key);
				field.setAccessible(true);
				field.set(this, value);
			} catch (java.lang.NoSuchFieldException e) {
				System.out.println(this.getClass().getSimpleName() + " not exist type " + key);
			}
		}
	}
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@EqualsAndHashCode(callSuper=false)
	public static class Dependencies {
		List<PomBase> dependencies = new ArrayList<>();
		public void add(PomBase pomBase) {
			dependencies.add(pomBase);
		}
	}
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@EqualsAndHashCode(callSuper=false)
	public static class DependencyManagement {
		Dependencies dependencies;
	}
}
