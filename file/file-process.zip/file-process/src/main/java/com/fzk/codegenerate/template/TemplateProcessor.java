package com.fzk.codegenerate.template;

import java.util.Map;

public interface TemplateProcessor {
	String process(String templatePath, Map<String, Object> data) throws Exception;
}
