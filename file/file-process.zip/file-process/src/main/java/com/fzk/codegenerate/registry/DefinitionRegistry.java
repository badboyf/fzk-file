/*
 * @Title : DefiditionRegister.java
 * 
 * @version V1.0
 * 
 * @date：2018年11月1日
 * 
 * @Copyright © 2018 江苏华叶跨域教育科技发展股份有限公司 Corporation. All rights reserved.
 */
package com.fzk.codegenerate.registry;

import com.fzk.codegenerate.context.ModelHolder;
import com.fzk.codegenerate.wrapper.ModelWrapper;

/** 
 * @ClassName: DefiditionRegister 
 * @Description: 
 * @author fengzhikui
 * @date 2018年11月1日 
 *  
 */
public interface DefinitionRegistry {
	void regist(ModelWrapper model, ModelHolder modelHolder);
	
	boolean needRegist(ModelWrapper model);
}
