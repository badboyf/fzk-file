package com.fzk.codegenerate.definition;

public interface Definition {
	String getDestFilePath();

	Class<?> getBaseClass();

	String getDefinitionType();

	String getName();

	String getPackageName();
}
