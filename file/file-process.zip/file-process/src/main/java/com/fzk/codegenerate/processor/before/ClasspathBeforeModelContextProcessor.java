package com.fzk.codegenerate.processor.before;

import java.io.File;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;

import com.fzk.codegenerate.context.ApplicationContext;
import com.fzk.codegenerate.context.ConfigAppContext;
import com.fzk.codegenerate.processor.BeforeApplicationProcessor;

public class ClasspathBeforeModelContextProcessor implements BeforeApplicationProcessor {

	@Override
	public void process() {
		String targetPath = ApplicationContext.getInstance().getClassesDirPath();
		try {
			addClassPath(targetPath);
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public static void addClassPath(String filePath) throws Exception {
		File clazzPath = new File(filePath);
		Method add = URLClassLoader.class.getDeclaredMethod("addURL", new Class[] { URL.class });
		add.setAccessible(true);
		add.invoke(ConfigAppContext.CLASS_LOADER, new Object[] { clazzPath.toURI().toURL() });
	}

	@Override
	public int getOrder() {

		return 1;
	}
}
