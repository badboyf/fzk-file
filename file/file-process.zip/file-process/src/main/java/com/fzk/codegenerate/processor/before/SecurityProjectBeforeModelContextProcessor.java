package com.fzk.codegenerate.processor.before;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.HashMap;
import java.util.Map;

import com.fzk.codegenerate.context.ApplicationContext;
import com.fzk.codegenerate.processor.BeforeApplicationProcessor;
import com.fzk.codegenerate.template.impl.DefaultTemplateProcessor;
import com.fzk.codegenerate.util.PomUtil;
import com.fzk.codegenerate.vo.PomBean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

public class SecurityProjectBeforeModelContextProcessor implements BeforeApplicationProcessor {

	@Override
	public void process() {
		try {
			doProcess();
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	private void doProcess() throws Exception {
		String securityPathPrefix = ApplicationContext.getInstance().getConfigContext().getSecurityDestPathPrefix();
		String projectPath = ApplicationContext.getInstance().getConfigContext().getDestPathPrefix();
		projectPath = projectPath.substring(0, projectPath.indexOf("/src/main/java"));
		if (securityPathPrefix == null) {
			return;
		}
		if (securityPathPrefix.endsWith("/")) {
			securityPathPrefix = securityPathPrefix.substring(0, securityPathPrefix.length() - 1);
		}
		int beginIndex = securityPathPrefix.lastIndexOf("/") + 1;
		int endIndex = securityPathPrefix.length();
		String securityProjectName = securityPathPrefix.substring(beginIndex, endIndex);
		String subSecurityName = securityProjectName + "-base";
		String subSecurityPath = securityPathPrefix + "/" + subSecurityName;
		String subPomPath = subSecurityPath + "/pom.xml";
		if (!new File(subSecurityPath).exists()) {
			new File(subSecurityPath).mkdirs();
		}
		System.out.println("dest path:" + subPomPath);
		File file = new File(subPomPath);
		if (file.exists()) {
			System.out.println("file exist, pass");
			return;
		}
		String securityPomPath = securityPathPrefix + "/pom.xml";
		PomBean.Pom securityPom = PomUtil.localUrlToMap(securityPomPath);
		String servicePomPath = projectPath + "/pom.xml";
		PomBean.Pom servicePom = PomUtil.localUrlToMap(servicePomPath);

		Map<String, Object> value = new HashMap<>();
		value.put("groupId", subSecurityName);
		value.put("parent_groupId", securityPom.getGroupId() == null ? securityPom.getParent().getGroupId() : securityPom.getGroupId());
		value.put("parent_artifactId", securityPom.getArtifactId());
		value.put("parent_version", securityPom.getVersion() == null ? securityPom.getParent().getVersion() : securityPom.getVersion());
		value.put("service_groupId", servicePom.getGroupId() == null ? servicePom.getParent().getGroupId() : servicePom.getGroupId());
		value.put("service_artifactId", servicePom.getArtifactId());
		value.put("version", securityPom.getVersion() == null ? securityPom.getParent().getVersion() : securityPom.getVersion());
		
		String tmpPath = ApplicationContext.getInstance().getPluginPath() + "file/lombok-tmplate/Pom";
		String data = new DefaultTemplateProcessor().process(tmpPath, value);

		FileWriter fw = new FileWriter(subPomPath);
		BufferedWriter bw = new BufferedWriter(fw);

		try {
			bw.write(data);
			bw.flush();
		} catch (Exception e) {
			if (fw != null) {
				fw.close();
			}
			if (bw != null) {
				bw.close();
			}
		}
		System.out.println("pom generate ok");
	}

	String getContent(String path) throws Exception {
		StringBuffer result = new StringBuffer();
		FileReader fr = null;
		BufferedReader br = null;
		try {
			fr = new FileReader(path);
			br = new BufferedReader(fr);

			String line = br.readLine();
			while (line != null) {
				result.append(line);
				result.append("\r");

				line = br.readLine();
			}
		} finally {
			if (br != null) {
				br.close();
			}
		}

		return result.toString();
	}

	@Override
	public int getOrder() {

		return 3;
	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	private static final class PomParam {
		String groupId;
		String artifactId;
		String version;
		String parentGroupId;
		String parentArtifactId;
		String parentVersion;
	}
}
