package com.fzk.codegenerate.registry.impl;

import com.fzk.codegenerate.context.ApplicationContext;
import com.fzk.codegenerate.context.ConfigAppContext;
import com.fzk.codegenerate.definition.CommonDefinition;
import com.fzk.codegenerate.definition.Definition;
import com.fzk.codegenerate.registry.AbstractSingleDefinitionRegistry;
import com.fzk.codegenerate.util.Constant;
import com.fzk.codegenerate.util.Util;
import com.fzk.codegenerate.wrapper.ModelWrapper;
import com.fzk.codegenerate.wrapper.ModelWrapper.Type;

public class DtoDefinitionRegistry extends AbstractSingleDefinitionRegistry {

	@Override
	public Definition getDefinition(ModelWrapper wrapper) {
		String name = getName(wrapper);
		String packageName = getPackageName(wrapper);
		
		Class<?> baseClass = wrapper.getBaseClass();
		String destFilePath = getDestFilePath(packageName, name);
		String type = getType();
		Definition definition = new CommonDefinition(name, packageName, baseClass, destFilePath, type);

		return definition;
	}
	
	public String getDestFilePath(String packageName, String name) {
		String destPathPrefix = ApplicationContext.getInstance().getConfigContext().getApiDestPathPrefix();
		if (destPathPrefix == null) {
			destPathPrefix = getDestPathPrefix();
		}
		
		return destPathPrefix + Util.packageToFolder(packageName) + "/" + name + ".java";
	}
	
	public String getPackageName(ModelWrapper wrapper) {
		ApplicationContext context = ApplicationContext.getInstance();
		ConfigAppContext configContext = context.getConfigContext();
		String modelPackage = configContext.getModelPackage();
		String packageSubfix = Constant.PACKAGE_SUBFIX.get(getType());
		String appBasePackage = configContext.getBasePackage();
		String domainPackage = context.getDomainPackage();
		String baseClassPackageName = wrapper.getBaseClass().getPackage().getName();
		String result = null;
		if (wrapper.getType() == Type.MODEL) {
			result = appBasePackage + "." + domainPackage + "." + packageSubfix;
		} else {
			String subfix = baseClassPackageName.substring(baseClassPackageName.indexOf(modelPackage) + modelPackage.length() + 1);
			result = appBasePackage + "." + domainPackage + "." + packageSubfix + "." + subfix;
		}
		return result;
	}

	@Override
	public String getType() {
		
		return Constant.TYPE_DTO;
	}
}
