package com.fzk.codegenerate.context;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fzk.codegenerate.definition.Definition;

public class ModelHolder {

	private static ModelHolder instance = new ModelHolder();

	private ModelHolder() {
	}

	public static ModelHolder getInstance() {
		return instance;
	}

	private Map<Class<?>, List<Definition>> definitionMap = new HashMap<>();
	private List<Definition> definitions = new ArrayList<>();

	public void registerDefinition(Definition definition) {
		this.definitions.add(definition);
		List<Definition> list = definitionMap.get(definition.getBaseClass());
		if (list == null) {
			list = new ArrayList<>();
			definitionMap.put(definition.getBaseClass(), list);
		}
		list.add(definition);
	}

	public List<Definition> getDefinitions() {
		return definitions;
	}

	public Collection<Class<?>> allBaseClass() {
		return definitionMap.keySet();
	}

//	@SuppressWarnings("unchecked")
//	public <T extends Definition> T get(Class<?> clazz, String type) {
//		List<Definition> list = definitionMap.get(clazz);
//		if (list == null) {
//			return null;
//		}
//		for (Definition definition : list) {
//			if (definition.getDefinitionType().equals(type)) {
//				return (T) definition;
//			}
//		}
//		return null;
//	}

	@SuppressWarnings("unchecked")
	public <T extends Definition> T get(String baseClassName, String type) {
		List<Definition> definitions = new ArrayList<>();
		for (Class<?> clazz : definitionMap.keySet()) {
			if (clazz.getName().equals(baseClassName)) {
				definitions = definitionMap.get(clazz);
			}
		}
		for (Definition definition : definitions) {
			if (definition.getDefinitionType().equals(type)) {
				return (T) definition;
			}
		}
		return null;
	}

	public boolean containsType(String type) {
		for (Class<?> clazz : allBaseClass()) {
			if (clazz.getName().equals(type) || clazz.getSimpleName().equals(type)) {
				return true;
			}
		}

		return false;
	}
}
