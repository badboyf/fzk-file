/*
 * @Title : DefaultModelWrapper.java
 * 
 * @version V1.0
 * 
 * @date：2018年11月1日
 * 
 * @Copyright © 2018 江苏华叶跨域教育科技发展股份有限公司 Corporation. All rights reserved.
 */
package com.fzk.codegenerate.wrapper.finder.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.fzk.codegenerate.wrapper.ModelWrapper;
import com.fzk.codegenerate.wrapper.finder.ModelWrapperFinder;

/** 
 * @ClassName: DefaultModelWrapper 
 * @Description: 
 * @author fengzhikui
 * @date 2018年11月1日 
 *  
 */
public class DefaultModelWrapperFinder implements ModelWrapperFinder {
	private List<String> skips = new ArrayList<>();

	public DefaultModelWrapperFinder() {
		this(Arrays.asList("factory", "repository"));
	}

	public DefaultModelWrapperFinder(List<String> skip) {
		this.skips = skip;
	}

	@Override
	public List<ModelWrapper> find(String path) {
		List<File> processFiles = findNeedProcessBeans(path);
		List<ModelWrapper> result = new ArrayList<>();
		for (File file : processFiles) {
			String tmp = file.getAbsolutePath().replace("\\", "/");
			result.add(new ModelWrapper(tmp));
		}

		return result;
	}

	public List<File> findNeedProcessBeans(String modelFileDir) {
		File domainDir = new File(modelFileDir);

		List<File> results = findAllFile(domainDir);
		return results;
	}

	private boolean shouldRemoveByName(File file) {

		return this.skips.contains(file.getName());
	}

	private List<File> findAllFile(File file) {
		List<File> result = new ArrayList<>();
		if (shouldRemoveByName(file)) {
			return result;
		}
		if (file.isFile()) {
			result.add(file);
		} else if (file.isDirectory()) {
			File[] subs = file.listFiles();
			for (File sub : subs) {
				List<File> files = findAllFile(sub);
				result.addAll(files);
			}
		}

		return result;
	}
}
