/*
 * @Title : TemplatePath.java
 * 
 * @version V1.0
 * @date：2018年11月15日
 * @Copyright © 2018 江苏华叶跨域教育科技发展股份有限公司 Corporation. All rights reserved. 
 */
package com.fzk.codegenerate.template;

import com.fzk.codegenerate.definition.Definition;

/** 
 * @ClassName: TemplatePath 
 * @Description: 
 * @author fengzhikui
 * @date 2018年11月15日 
 *  
 */
public interface TemplatePath {
	String getPath(Definition definition);
}
