package com.fzk.codegenerate.template.impl;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.List;
import java.util.Map;

import com.fzk.codegenerate.template.TemplateProcessor;

public class DefaultTemplateProcessor implements TemplateProcessor {

	@SuppressWarnings("unchecked")
	public String process(String templatePath, Map<String, Object> replace) throws Exception {
		StringBuffer result = new StringBuffer();

		FileReader fr = null;
		BufferedReader br = null;
		try {
			fr = new FileReader(templatePath);
			br = new BufferedReader(fr);

			String line = br.readLine();
			while (line != null) {
				for (String key : replace.keySet()) {
					Object value = replace.get(key);
					if (line.indexOf("#{" + key + "}") >= 0) {
						String v = (String) value;
						line = line.replace("#{" + key + "}", v);
					}
					if (line.indexOf("#[" + key + "]") >= 0) {
						boolean inline = line.indexOf("#[" + key + "]#") >= 0;
						StringBuffer sbTmp = new StringBuffer();
						List<String> v = (List<String>) value;
						for (int i = 0; i < v.size(); i++) {
							sbTmp.append(v.get(i));
							if (!inline && i < v.size() - 1) {
								sbTmp.append("\n");
							} else {
								sbTmp.append("");
							}
						}
						line = sbTmp.toString();
					}
				}
				result.append(line);
				result.append("\n");

				line = br.readLine();
			}
		} finally {
			if (br != null) {
				br.close();
			}
		}

		return result.toString();
	}
}
