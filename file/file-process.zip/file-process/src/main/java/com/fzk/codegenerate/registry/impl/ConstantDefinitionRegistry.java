package com.fzk.codegenerate.registry.impl;

import com.fzk.codegenerate.context.ApplicationContext;
import com.fzk.codegenerate.definition.CommonDefinition;
import com.fzk.codegenerate.definition.Definition;
import com.fzk.codegenerate.registry.AbstractSingleDefinitionRegistry;
import com.fzk.codegenerate.util.Constant;
import com.fzk.codegenerate.util.Util;
import com.fzk.codegenerate.wrapper.ModelWrapper;

public class ConstantDefinitionRegistry extends AbstractSingleDefinitionRegistry {

	@Override
	public Definition getDefinition(ModelWrapper model) {
		if (model.getType() != ModelWrapper.Type.MODEL) {
			return null;
		}

		String name = getName(model);
		String packageName = getPackageName();
		Class<?> baseClass = model.getBaseClass();
		String destFilePath = getDestFilePath(packageName, name);
		String type = getType();
		Definition definition = new CommonDefinition(name, packageName, baseClass, destFilePath, type);

		return definition;
	}
	
	public String getPackageName() {
		String packageSubfix = Constant.PACKAGE_SUBFIX.get(getType());
		String appBasePackage = ApplicationContext.getInstance().getConfigContext().getBasePackage();
		String domainPackage = ApplicationContext.getInstance().getDomainPackage();
		return appBasePackage + "." + domainPackage + "." + packageSubfix;
	}

	public String getDestFilePath(String packageName, String name) {
		String destPathPrefix = ApplicationContext.getInstance().getConfigContext().getEventDestPathPrefix();
		if (destPathPrefix == null) {
			destPathPrefix = getDestPathPrefix();
		}

		return destPathPrefix + Util.packageToFolder(packageName) + "/" + name + ".java";
	}

	@Override
	public String getType() {

		return Constant.TYPE_EVENT_CONSTANT;
	}

}
