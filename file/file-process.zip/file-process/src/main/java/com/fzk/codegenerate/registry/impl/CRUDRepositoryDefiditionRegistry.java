package com.fzk.codegenerate.registry.impl;

import com.fzk.codegenerate.definition.CommonDefinition;
import com.fzk.codegenerate.definition.Definition;
import com.fzk.codegenerate.registry.AbstractSingleDefinitionRegistry;
import com.fzk.codegenerate.util.Constant;
import com.fzk.codegenerate.wrapper.ModelWrapper;

public class CRUDRepositoryDefiditionRegistry extends AbstractSingleDefinitionRegistry {

	@Override
	public Definition getDefinition(ModelWrapper wrapper) {
		if (wrapper.getType() != ModelWrapper.Type.MODEL) {
			return null;
		}

		String name = getName(wrapper);
		String packageName = getPackageName(wrapper);
		Class<?> baseClass = wrapper.getBaseClass();
		String destFilePath = getDestFilePath(packageName, name);
		String type = getType();
		Definition definition = new CommonDefinition(name, packageName, baseClass, destFilePath, type);

		return definition;
	}

	@Override
	public String getType() {

		return Constant.TYPE_CRUD_REPOSITORY;
	}

}
