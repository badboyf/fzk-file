package com.fzk.codegenerate.processor;

import java.util.List;

import com.fzk.codegenerate.definition.Definition;

public interface AfterApplicationProcessor extends ApplicationProcessor {
	public void process(List<Definition> definitions);
}
