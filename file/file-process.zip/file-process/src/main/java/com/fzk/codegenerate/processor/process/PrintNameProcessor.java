/*
 * @Title : PrintNameProcessor.java
 * 
 * @version V1.0
 * @date：2018年11月7日
 * @Copyright © 2018 江苏华叶跨域教育科技发展股份有限公司 Corporation. All rights reserved. 
 */
package com.fzk.codegenerate.processor.process;

import java.io.File;

import com.fzk.codegenerate.definition.Definition;
import com.fzk.codegenerate.processor.DefinitionProcessor;

/** 
 * @ClassName: PrintNameProcessor 
 * @Description: 
 * @author fengzhikui
 * @date 2018年11月7日 
 *  
 */
public class PrintNameProcessor implements DefinitionProcessor{

	@Override
	public void process(Definition definition) {
		System.out.println("exsit=" + new File(definition.getDestFilePath()).exists() + "   " + definition.getDestFilePath());
	}

}
