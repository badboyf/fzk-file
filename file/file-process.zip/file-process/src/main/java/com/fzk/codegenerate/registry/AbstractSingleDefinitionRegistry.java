package com.fzk.codegenerate.registry;

import java.util.ArrayList;
import java.util.List;

import com.fzk.codegenerate.definition.Definition;
import com.fzk.codegenerate.util.Constant;
import com.fzk.codegenerate.wrapper.ModelWrapper;

public abstract class AbstractSingleDefinitionRegistry extends AbstractDefinitionRegistry {

	public List<Definition> getDefinitions(ModelWrapper model) {
		List<Definition> result = new ArrayList<>();
		Definition definition = getDefinition(model);
		if (definition != null) {
			result.add(definition);
		}

		return result;
	}

	public String getName(ModelWrapper model) {
		String nameSubfix = getNameSubfix();
		if (nameSubfix == null) {
			nameSubfix = Constant.NAME_SUBFIX.get(getType());
		}
		if (nameSubfix == null) {
			throw new RuntimeException("should suply either method getNameSubfix() or getType() and config the NAME_SUBFIX constant");
		}
		return getNamePrefix() + model.getBaseClass().getSimpleName() + nameSubfix;
	}

	public abstract Definition getDefinition(ModelWrapper model);
}
