package com.fzk.codegenerate.registry.impl;

import java.util.List;

import com.fzk.codegenerate.context.ApplicationContext;
import com.fzk.codegenerate.definition.Definition;
import com.fzk.codegenerate.definition.TypeCommonDefinition;
import com.fzk.codegenerate.registry.AbstractTypeDefinitionRegistry;
import com.fzk.codegenerate.util.Constant;
import com.fzk.codegenerate.util.Util;
import com.fzk.codegenerate.wrapper.ModelWrapper;

public class EventDefinitionRegistry extends AbstractTypeDefinitionRegistry {

	@Override
	public Definition getDefinition(ModelWrapper model, String type) {
		String name = getName(model, type);
		String packageName = getPackageName(model);
		Class<?> baseClass = model.getBaseClass();
		String destFilePath = getDestFilePath(packageName, name);
		String definitionType = getType();
		Definition definition = new TypeCommonDefinition(name, packageName, type, baseClass, destFilePath, definitionType);

		return definition;
	}
	
	public String getPackageName(ModelWrapper model) {
		String packageSubfix = Constant.PACKAGE_SUBFIX.get(getType());
		String appBasePackage = ApplicationContext.getInstance().getConfigContext().getBasePackage();
		String domainPackage = ApplicationContext.getInstance().getDomainPackage();
		return appBasePackage + "." + domainPackage + "." + packageSubfix;
	}
	
	public String getDestFilePath(String packageName, String name) {
		String destPathPrefix = ApplicationContext.getInstance().getConfigContext().getEventDestPathPrefix();
		if (destPathPrefix == null) {
			destPathPrefix = getDestPathPrefix();
		}
		
		return destPathPrefix + Util.packageToFolder(packageName) + "/" + name + ".java";
	}

	@Override
	public String getType() {

		return Constant.TYPE_EVENT;
	}

	@Override
	public List<String> getTypes(ModelWrapper model) {
		
		return ApplicationContext.getInstance().getConfigContext().getCrdTypes();
	}

	@Override
	public boolean needRegist(ModelWrapper model) {

		return model.getType() == ModelWrapper.Type.MODEL;
	}
}
