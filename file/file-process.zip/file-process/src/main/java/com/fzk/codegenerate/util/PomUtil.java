package com.fzk.codegenerate.util;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.fzk.codegenerate.vo.PomBean;

public class PomUtil {
	
	public static PomBean.Pom localUrlToMap(String localUrl) throws Exception {
		return streamToMap(new FileInputStream(new File(localUrl)));
	}

	public static PomBean.Pom xmlToMap(String strXML) throws Exception {
		InputStream stream = new ByteArrayInputStream(strXML.getBytes("UTF-8"));
		
		return streamToMap(stream);
	}
	
	public static PomBean.Pom streamToMap(InputStream stream) throws Exception {
		DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
		
		Document doc = documentBuilder.parse(stream);
		doc.getDocumentElement().normalize();
		PomBean.Pom result = docToMap(doc);
		try {
			stream.close();
		} catch (Exception ex) {
			ex.printStackTrace();
			throw ex;
		}
		return result;
	}
	
	private static PomBean.Pom docToMap(org.w3c.dom.Document doc) throws Exception {
		NodeList childNodes = doc.getChildNodes();
		for (int idx = 0; idx < childNodes.getLength(); ++idx) {
			Node node = childNodes.item(idx);
			PomBean.Pom pom = processPom(node.getChildNodes());
			
			if (pom != null) {
				return pom;
			}
		}
		
		return null;
	}

	private static PomBean.Pom processPom(NodeList nodeList) throws Exception  {
		PomBean.Pom pom = new PomBean.Pom();
		for (int idx = 0; idx < nodeList.getLength(); ++idx) {
			Node node = nodeList.item(idx);
			if (node.getNodeType() != Node.ELEMENT_NODE) {
				continue;
			}
			String key = node.getNodeName();
			if ("parent".equals(key)) {
				PomBean.PomBase parent = processBase(node);
				pom.setParent(parent);
			} else if ("dependencies".equals(key)) {
				PomBean.Dependencies dependencies = processDependencies(node);
				pom.setDependencies(dependencies);
			} else if ("dependencyManagement".equals(key)) {
				PomBean.DependencyManagement dependencyManagement = processDependencyManagement(node);
				pom.setDependencyManagement(dependencyManagement);
			} else if (PomBean.PomBase.GROUP_ID.equals(key)) {
				String groupId = getValue(node);
				pom.setGroupId(groupId);
			} else if (PomBean.PomBase.ARTIFACT_ID.equals(key)) {
				String artifactId = getValue(node);
				pom.setArtifactId(artifactId);
			} else if (PomBean.PomBase.VERSION.equals(key)) {
				String version = getValue(node);
				pom.setVersion(version);
			} else {
				System.out.println("not support " + key);
			}
		}
		
		return pom;
	}

	private static PomBean.DependencyManagement processDependencyManagement(Node node) throws Exception  {
		PomBean.DependencyManagement dependencyManagement = new PomBean.DependencyManagement();
		NodeList childs = node.getChildNodes();
		for (int idx = 0; idx < childs.getLength(); ++idx) {
			Node child = childs.item(idx);
			if (child.getNodeType() == Node.ELEMENT_NODE && "dependencies".equals(child.getNodeName())) {
				PomBean.Dependencies dependencies = processDependencies(child);
				dependencyManagement.setDependencies(dependencies);
			}
		}

		return dependencyManagement;
	}
	
	private static PomBean.Dependencies processDependencies(Node node) throws Exception  {
		PomBean.Dependencies dependencies = new PomBean.Dependencies();
		NodeList childs = node.getChildNodes();
		for (int idx = 0; idx < childs.getLength(); ++idx) {
			Node child = childs.item(idx);
			if (child.getNodeType() == Node.ELEMENT_NODE) {
				String key = child.getNodeName();
				if ("dependency".equals(key)) {
					dependencies.add(processBase(child));
				}
			}
		}
		
		return dependencies;
	}
	
	private static PomBean.PomBase processBase(Node node) throws Exception {
		PomBean.PomBase pomBase = new PomBean.PomBase();
		NodeList childs = node.getChildNodes();
		for (int idx = 0; idx < childs.getLength(); ++idx) {
			Node child = childs.item(idx);
			if (child.getNodeType() == Node.ELEMENT_NODE) {
				String key = child.getNodeName();
				String value = getValue(child);
				pomBase.set(key, value);
			}
		}
		return pomBase;
	}
	
	private static String getValue(Node node) {
		NodeList childs = node.getChildNodes();
		for (int idx = 0; idx < childs.getLength(); ++idx) {
			Node child = childs.item(idx);
			if (child.getNodeType() == Node.TEXT_NODE) {
				String value = child.getNodeValue();
				if (!isNull(value)) {
					return value;
				}
			}
		}
		return null;
	}
	
	private static boolean isNull(String value) {
		return value == null || value.trim().equals("");
	}
	
}
