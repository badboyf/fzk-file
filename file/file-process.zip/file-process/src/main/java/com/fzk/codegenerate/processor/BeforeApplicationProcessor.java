package com.fzk.codegenerate.processor;

public interface BeforeApplicationProcessor extends ApplicationProcessor{
	void process();
}
