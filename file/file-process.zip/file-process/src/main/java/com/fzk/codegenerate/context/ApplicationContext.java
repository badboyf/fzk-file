package com.fzk.codegenerate.context;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class ApplicationContext {
	private static ApplicationContext instance = new ApplicationContext();

	private ApplicationContext() {
	}

	public static ApplicationContext getInstance() {
		return instance;
	}

	private String pluginPath;

	private String classesDirPath;
	private String appBasePackage;
	private String domainPackage;
	private String modelFileDir;
	private Map<String, String> templatePathMap = new HashMap<>();

	ConfigAppContext configContext;

	public void fresh(String pluginPath, ConfigAppContext configContext) {
		this.pluginPath = pluginPath;

		this.configContext = configContext;
		this.classesDirPath = configContext.getProject() + "/target/classes";
		this.modelFileDir = initModelFileDir();
		String tmpPackage = modelFileDir.replace("/", ".");

		int startIndex = tmpPackage.indexOf(configContext.getBasePackage());
		int endIndex = tmpPackage.indexOf(configContext.getModelPackage()) - 1;
		this.appBasePackage = tmpPackage.substring(startIndex, endIndex);

		startIndex = tmpPackage.indexOf(configContext.getBasePackage()) + configContext.getBasePackage().length() + 1;
		endIndex = tmpPackage.indexOf(configContext.getModelPackage()) - 1;
		this.domainPackage = tmpPackage.substring(startIndex, endIndex);
		if (this.domainPackage.endsWith(".app")) {
			this.domainPackage = this.domainPackage.substring(0, this.domainPackage.length() - ".app".length());
		} else if (this.domainPackage.endsWith(".search")) {
			this.domainPackage = this.domainPackage.substring(0, this.domainPackage.length() - ".search".length());
		}
	}

	private String initModelFileDir() {
		File file = new File(classesDirPath);
		File domainDirFile = findModel(file.listFiles());
		System.out.println("find domain path : " + domainDirFile.getAbsolutePath());
		String basePackage = domainDirFile.getAbsolutePath().replace("\\", "/");

		return basePackage;
	}

	private File findModel(File[] files) {
		for (File tmp : files) {
			if (!tmp.isDirectory()) {
				continue;
			}
			if (tmp.getAbsolutePath().endsWith(configContext.getModelPackage().replace(".", File.separator))) {
				String processModel = configContext.getProcessModel();
				if (processModel == null || tmp.getAbsolutePath().contains(processModel.replace(".", File.separator))) {
					return tmp;
				}
			} else {
				File[] listFiles = tmp.listFiles();
				File domainDir = findModel(listFiles);
				if (domainDir != null) {
					return domainDir;
				}
			}
		}
		return null;
	}

	public String getAppBasePackage() {
		return appBasePackage;
	}
	public String getClassesDirPath() {
		return classesDirPath;
	}
	public ConfigAppContext getConfigContext() {
		return configContext;
	}
	public String getDomainPackage() {
		return domainPackage;
	}
	public String getModelFileDir() {
		return modelFileDir;
	}
	public String getPluginPath() {
		return pluginPath;
	}
	public Map<String, String> getTemplatePathMap() {
		return templatePathMap;
	}
}
