package com.fzk.codegenerate.definition;

public class CommonDefinition implements Definition {
	private String name;

	private String packageName;

	private Class<?> baseClass;

	private String fileDestPath;

	private String definitionType;

	public CommonDefinition() {
	}

	public CommonDefinition(String name, String packageName, Class<?> baseClass, String fileDestPath, String definitionType) {
		this.name = name;
		this.packageName = packageName;
		this.baseClass = baseClass;
		this.fileDestPath = fileDestPath;
		this.definitionType = definitionType;
	}

	@Override
	public String getDestFilePath() {
		return fileDestPath;
	}

	@Override
	public Class<?> getBaseClass() {
		return this.baseClass;
	}

	@Override
	public String getDefinitionType() {
		return definitionType;
	}

	public String getName() {
		return name;
	}

	public String getFileDestPath() {
		return fileDestPath;
	}

	public String getPackageName() {
		return packageName;
	}

}
