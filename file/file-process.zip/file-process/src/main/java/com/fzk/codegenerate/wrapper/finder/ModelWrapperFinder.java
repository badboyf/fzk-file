/*
 * @Title : ModelWrapperFinder.java
 * 
 * @version V1.0
 * 
 * @date：2018年11月1日
 * 
 * @Copyright © 2018 江苏华叶跨域教育科技发展股份有限公司 Corporation. All rights reserved.
 */
package com.fzk.codegenerate.wrapper.finder;

import java.util.List;

import com.fzk.codegenerate.wrapper.ModelWrapper;

/** 
 * @ClassName: ModelWrapperFinder 
 * @Description: 
 * @author fengzhikui
 * @date 2018年11月1日 
 *  
 */
public interface ModelWrapperFinder {

	List<ModelWrapper> find(String path);
}
