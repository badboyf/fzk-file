package com.fzk.codegenerate.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class FileGenerator {

	private boolean override = false;

	public FileGenerator() {
	}

	public FileGenerator(boolean override) {
		this.override = override;
	}

	public void generate(String data, String filePath) throws IOException {
		File file = new File(filePath);

		if (!file.getParentFile().exists()) {
			file.getParentFile().mkdirs();
		}
		System.out.println("dest path:" + filePath);

		if (file.exists() && !override) {
			System.out.println("file exist, pass");
		}

		FileWriter fw = new FileWriter(filePath);
		BufferedWriter bw = new BufferedWriter(fw);

		try {
			bw.write(data);
			bw.flush();
		} catch (Exception e) {
			if (fw != null) {
				fw.close();
			}
			if (bw != null) {
				bw.close();
			}
		}
	}

}
