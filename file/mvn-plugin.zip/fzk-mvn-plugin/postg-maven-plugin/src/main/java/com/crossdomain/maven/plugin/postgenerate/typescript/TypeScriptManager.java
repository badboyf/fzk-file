package com.crossdomain.maven.plugin.postgenerate.typescript;

import java.util.ArrayList;
import java.util.List;

import org.apache.maven.plugin.MojoFailureException;

import com.crossdomain.maven.plugin.postgenerate.typescript.handler.ApiTS;
import com.crossdomain.maven.plugin.postgenerate.typescript.handler.ConfigurationTS;
import com.crossdomain.maven.plugin.postgenerate.typescript.handler.NpmIgnore;

public class TypeScriptManager {

	private final List<TypeScriptHandler> ts;

	public TypeScriptManager(String rootPath) {
		this.ts = new ArrayList<>();
		this.ts.add(new ConfigurationTS(rootPath));
		this.ts.add(new ApiTS(rootPath));
		this.ts.add(new NpmIgnore(rootPath));
	}

	public void process() throws MojoFailureException {
		
		for (TypeScriptHandler typeScriptHandler : ts) {
			typeScriptHandler.handle();
		}
	}

}
