package com.crossdomain.maven.plugin.postgenerate;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.Map.Entry;

import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.MojoFailureException;
import org.apache.maven.plugins.annotations.LifecyclePhase;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;
import org.codehaus.plexus.util.IOUtil;

import com.crossdomain.maven.plugin.postgenerate.typescript.TypeScriptManager;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.TextNode;

@Mojo(name = "pg", defaultPhase = LifecyclePhase.INSTALL)
public class Bootstrap extends AbstractMojo {

	@Parameter(property = "srcFolder", required = true, defaultValue = "${project.build.directory}/generated-sources/swagger")
	private String srcFolder;

	@Parameter(property = "peerDepFile")
	private String peerDepFile = null;

	@Parameter(property = "devDepFile")
	private String devDepFile = null;

	@Parameter(property = "typingFile")
	private String typingFile = null;
	
	@Parameter(property = "appName", required = false)
	private String appName;

	private static final String PEER_DEP_TAG = "peerDependencies";
	private static final String DEV_DEP_TAG = "devDependencies";
	
	
	private static final String DEV_DEP_FILE = "devDep.json";
	private static final String PEER_DEP_FILE = "peerDep.json";
	private static final String TYPING_FILE = "typing.json";
	private static final String SCRIPTS_FILE = "scripts.json";


	private static String DEFAULT_SCRIPTS;
	private static String DEFAULT_DEV_DEP_CONTENT;
	private static String DEFAULT_PEER_DEP_CONTENT;
	private static String DEFAULT_TYPING_CONTENT = "{}";

	

	static {
		try {
			ClassLoader classLoader = Bootstrap.class.getClassLoader();
			InputStream resourceAsStream = classLoader.getResourceAsStream(DEV_DEP_FILE);
			DEFAULT_DEV_DEP_CONTENT = IOUtil.toString(resourceAsStream);
			resourceAsStream.close();
			resourceAsStream = classLoader.getResourceAsStream(PEER_DEP_FILE);
			DEFAULT_PEER_DEP_CONTENT = IOUtil.toString(resourceAsStream);
			resourceAsStream.close();
			resourceAsStream = classLoader.getResourceAsStream(TYPING_FILE);
			DEFAULT_TYPING_CONTENT = IOUtil.toString(resourceAsStream);
			resourceAsStream.close();
			resourceAsStream = classLoader.getResourceAsStream(SCRIPTS_FILE);
			DEFAULT_SCRIPTS = IOUtil.toString(resourceAsStream);
			resourceAsStream.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void execute() throws MojoExecutionException, MojoFailureException {
		try {
			processTypingfile();
			processPackageJson();
			processTsConfig();
			this.getLog().info("typeScriptManager start.");
			TypeScriptManager typeScriptManager = new TypeScriptManager(this.srcFolder);
			typeScriptManager.process();
		} catch (IOException e) {
			e.printStackTrace();
			throw new MojoFailureException(e, "文件处理失败", "文件处理未完成");
		}
	}

	private void processTsConfig() throws IOException {
		String tsConfigFile = new StringBuffer(this.srcFolder).append(File.separator).append("tsconfig.json")
				.toString();
		InputStream resourceAsStream = Bootstrap.class.getClassLoader().getResourceAsStream("tsconfig.json");
		FileOutputStream out = new FileOutputStream(tsConfigFile);
		IOUtil.copy(resourceAsStream, out);
		out.close();
		resourceAsStream.close();
	}

	private void processPackageJson() throws IOException {
		String packageJsonFile = new StringBuffer(this.srcFolder).append(File.separator).append("package.json")
				.toString();
		File proccessFile = new File(packageJsonFile);
		ObjectMapper mapper = new ObjectMapper();
		JsonNode readTree = mapper.readTree(proccessFile);
		ObjectNode objectNode = mapper.createObjectNode();
		JsonNode peerDepNode = readPeerDevNode(mapper);
		JsonNode devDepNode = readDevDepNode(mapper);
		
		JsonNode scriptsNode = readScriptsNode(mapper);
		Iterator<Entry<String, JsonNode>> fields = readTree.fields();
		while (fields.hasNext()) {
			Entry<String, JsonNode> next = fields.next();
			if (PEER_DEP_TAG.equals(next.getKey())) {
				objectNode.set(PEER_DEP_TAG, peerDepNode);
				continue;
			}
			if (DEV_DEP_TAG.equals(next.getKey())) {
				objectNode.set(DEV_DEP_TAG, devDepNode);
				continue;
			}
			if ("scripts".equals(next.getKey())) {
				objectNode.set("scripts", scriptsNode);
				continue;
			}
			objectNode.set(next.getKey(), next.getValue());
		}
		JsonNode appNameNode = new TextNode(this.appName);
		objectNode.set("appName", appNameNode);
		mapper.writerWithDefaultPrettyPrinter().writeValue(proccessFile, objectNode);
	}

	private JsonNode readDevDepNode(ObjectMapper mapper) throws JsonProcessingException, IOException {
		if (this.devDepFile !=null) {
			return mapper.readTree(new File(this.devDepFile));
		}
		return mapper.readTree(DEFAULT_DEV_DEP_CONTENT);
	}
	
	private JsonNode readScriptsNode(ObjectMapper mapper) throws JsonProcessingException, IOException {
		return mapper.readTree(DEFAULT_SCRIPTS);
	}

	private JsonNode readPeerDevNode(ObjectMapper mapper) throws JsonProcessingException, IOException {
		if (peerDepFile!=null) {
			return mapper.readTree(new File(this.peerDepFile));
		}
		return mapper.readTree(DEFAULT_PEER_DEP_CONTENT);
	}

	private void processTypingfile() throws IOException {
		String typingFile = new StringBuffer(this.srcFolder).append(File.separator).append("typings.json").toString();
		FileWriter fileWriter = new FileWriter(typingFile);
		if (this.typingFile == null) {
			fileWriter.write(DEFAULT_TYPING_CONTENT);
		} else {
			FileInputStream fileInputStream = new FileInputStream(this.typingFile);
			String content = IOUtil.toString(fileInputStream);
			fileInputStream.close();
			fileWriter.write(content);
		}
		fileWriter.close();
	}

}
