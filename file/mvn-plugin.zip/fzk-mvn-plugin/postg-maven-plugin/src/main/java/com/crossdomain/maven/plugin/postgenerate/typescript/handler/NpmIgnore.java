package com.crossdomain.maven.plugin.postgenerate.typescript.handler;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.apache.maven.plugin.MojoFailureException;

import com.crossdomain.maven.plugin.postgenerate.typescript.TypeScriptHandler;

public class NpmIgnore implements TypeScriptHandler{
	
	private static final String GITIGNORE = ".npmignore";
	private final String rootPath;
	
	public NpmIgnore(String rootPath) {
		this.rootPath = rootPath;
	}

	@Override
	public void handle() throws MojoFailureException {
		String npmIgnore = new StringBuffer(this.rootPath).append(File.separator).append(GITIGNORE)
				.toString();
		File f = new File(npmIgnore);
		
		try {
			f.createNewFile();
		} catch (IOException e) {
			throw new MojoFailureException(e, "npmignore处理失败", "npmignore处理未完成");
		}
		try (FileWriter writer = new FileWriter(f);){
			String ts = "wwwroot/*.js\n" + 
					"node_modules\n" + 
					"typings";
			writer.write(ts);
		} catch (Exception e) {
			throw new MojoFailureException(e, "npmignore处理失败", "npmignore处理未完成");
		}
		
	}

}
