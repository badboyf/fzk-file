package com.crossdomain.maven.plugin.postgenerate.typescript;

import org.apache.maven.plugin.MojoFailureException;

public interface TypeScriptHandler {
	
	void handle() throws MojoFailureException;

}
