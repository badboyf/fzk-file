package com.crossdomain.maven.plugin.postgenerate.typescript.handler;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.maven.plugin.MojoFailureException;
import org.codehaus.plexus.util.IOUtil;

import com.crossdomain.maven.plugin.postgenerate.typescript.TypeScriptHandler;

/**
 * change 
 * export * from './XXXApi'; 
 * import { XXXApi } from './XXXApi'; 
 * export const APIS = [XXXApi];
 * 
 * to 
 * export * from './XXXApi'; 
 * export * from './XXXApiInterface'; 
 * import { XXXApi } from './XXXApi'; 
 * export const APIS = [XXXApi];
 * 
 * @author lh
 *
 */
public class ApiTS implements TypeScriptHandler {

	private static final String API_MARK = "Api.ts";

	private static final String API_TS = "api.ts";

	private static final String API_DIR = "api";
	private static final String API_INTERFACE_MARK = "ApiInterface.ts";

	private final String rootPath;

	public ApiTS(String rootPath) {
		this.rootPath = rootPath;
	}

	@Override
	public void handle() throws MojoFailureException {
		String apiTsDir = new StringBuffer(this.rootPath).append(File.separator).append(API_DIR).toString();
		String apiTsFile = new StringBuffer(apiTsDir).append(File.separator).append(API_TS).toString();

		File apiDir = new File(apiTsDir);
		if(!apiDir.exists()) return;
		File[] tsFile = apiDir.listFiles();
		boolean hasInterface = false;
		List<String> interfaceNames = new ArrayList<>();
		for (File file : tsFile) {
			String fileName = file.getName();
			if(fileName.endsWith(API_INTERFACE_MARK)) {
				hasInterface = true;
			}
			
			if (fileName.endsWith(API_MARK)) {
				interfaceNames.add(fileName.replace(API_MARK, StringUtils.EMPTY));
			}
		}
		if(!hasInterface) {
			return;
		}

		if (interfaceNames.isEmpty()) {

		}

		InputStream in = null;
		FileWriter writer = null;
		try {
			File f = new File(apiTsFile);
			in = new FileInputStream(f);
			String ts = IOUtil.toString(in);
			int indexOf = StringUtils.indexOf(ts, ";");
			String start = ts.substring(0, indexOf);
			String end = ts.substring(indexOf, ts.length());
			
			StringBuffer interfaceExport = new StringBuffer();
			for (String interfaceName : interfaceNames) {
				interfaceExport.append(StringUtils.CR)
				.append("export * from './")
				.append(interfaceName)
				.append("ApiInterface'");
			}
			
			StringBuffer result = new StringBuffer(start)
					.append(";")
					.append(interfaceExport.toString())
					.append(end);

			writer = new FileWriter(f);
			writer.write(result.toString());
		} catch (IOException e) {
			throw new MojoFailureException(e, "TS文件处理失败", "TS文件处理未完成");
		} finally {
			try {
				if (writer != null) {
					writer.close();
				}
				if (in != null) {
					in.close();
				}
			} catch (IOException e) {
				throw new MojoFailureException(e, "TS文件处理失败", "TS文件处理未完成");
			}
		}

	}

}
