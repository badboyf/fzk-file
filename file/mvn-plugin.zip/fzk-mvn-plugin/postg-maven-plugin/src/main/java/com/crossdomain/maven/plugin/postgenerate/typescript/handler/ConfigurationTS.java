package com.crossdomain.maven.plugin.postgenerate.typescript.handler;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;

import org.apache.maven.plugin.MojoFailureException;
import org.codehaus.plexus.util.IOUtil;

import com.crossdomain.maven.plugin.postgenerate.typescript.TypeScriptHandler;

/**
 *  change
 *  withCredentials: boolean;
 *  
 *  to
 *  withCredentials: boolean = true;
 *  
 * @author lh
 *
 */
public class ConfigurationTS implements TypeScriptHandler {

	private static final String CONFIGURATION_TS = "configuration.ts";

	private final String rootPath;

	public ConfigurationTS(String rootPath) {
		this.rootPath = rootPath;
	}

	@Override
	public void handle() throws MojoFailureException {
		String configurationTsPath = new StringBuffer(this.rootPath).append(File.separator).append(CONFIGURATION_TS)
				.toString();
		InputStream in = null;
		FileWriter writer = null;
		try {
			File f = new File(configurationTsPath);
			if(!f.exists()) return;
			in = new FileInputStream(f);
			String ts = IOUtil.toString(in);
			ts = ts.replace("withCredentials: boolean", "withCredentials: boolean = true");
			writer = new FileWriter(f);
			writer.write(ts);
		} catch (IOException e) {
			throw new MojoFailureException(e, "TS文件处理失败", "TS文件处理未完成");
		} finally {
			try {
				if (writer != null) {
					writer.close();
				}
				if (in != null) {
					in.close();
				}
			} catch (IOException e) {
				throw new MojoFailureException(e, "TS文件处理失败", "TS文件处理未完成");
			}
		}

	}

}
