package com.crossdomain.maven.plugin.postgenerate;

import java.io.File;
import java.io.InputStream;
import java.net.URI;
import java.util.Iterator;
import java.util.Map.Entry;

import org.apache.maven.plugin.testing.AbstractMojoTestCase;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class BootstrapTest extends AbstractMojoTestCase {

	private static final String PACKAGE_JSON = "package.json";

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		InputStream resourceAsStream = this.getClassLoader().getResourceAsStream(PACKAGE_JSON);
		ObjectMapper mapper = new ObjectMapper();
		JsonNode readTree = mapper.readTree(resourceAsStream);
		Iterator<Entry<String, JsonNode>> fields = readTree.fields();
		ObjectNode objectNode = mapper.createObjectNode();
		while (fields.hasNext()) {
			Entry<String, JsonNode> next = fields.next();
			if(!"appName".equals(next.getKey())) {
				objectNode.set(next.getKey(), next.getValue());
			}
		}
//		URI uri = URI.create("file://"+getBasedir() + "/src/test/resources/package.json");
//		File file = new File(uri);
		File file = getTestFile("src/test/resources/" + PACKAGE_JSON);
		mapper.writerWithDefaultPrettyPrinter().writeValue(file , objectNode);
	}

	@Override
	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public void testPg001() throws Exception {
		File pom = getTestFile("src/test/resources/pom.xml");
		assertNotNull(pom);
		assertTrue(pom.exists());

		Bootstrap myMojo = (Bootstrap) lookupMojo("pg", pom);
		assertNotNull(myMojo);
		myMojo.execute();
		
		InputStream resourceAsStream = this.getClassLoader().getResourceAsStream(PACKAGE_JSON);
		ObjectMapper mapper = new ObjectMapper();
		JsonNode readTree = mapper.readTree(resourceAsStream);
		Iterator<Entry<String, JsonNode>> fields = readTree.fields();
		while (fields.hasNext()) {
			Entry<String, JsonNode> next = fields.next();
			if("appName".equals(next.getKey())) {
				assertEquals("hahaha", next.getValue().asText());
				return;
			}
		}
		assertTrue(false);

	}
}
