package com.fzk.swagger.models;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import io.swagger.models.Operation;
import io.swagger.models.Path;

@JsonPropertyOrder({ "gets", "heads", "posts", "puts", "deletes", "optionss", "patchs" })
public class ApiPath extends Path {
	private List<Operation> gets;
	private List<Operation> puts;
	private List<Operation> posts;
	private List<Operation> heads;
	private List<Operation> deletes;
	private List<Operation> patchs;
	private List<Operation> optionss;

	public ApiPath set(String method, Operation op) {
		if ("get".equals(method)) {
			if (this.gets == null) {
				this.gets = new ArrayList<>();
			}
			this.gets.add(op);
			return this;
		}
		if ("put".equals(method)) {
			if (this.puts == null) {
				this.puts = new ArrayList<>();
			}
			this.puts.add(op);
			return this;
		}
		if ("post".equals(method)) {
			if (this.posts == null) {
				this.posts = new ArrayList<>();
			}
			this.posts.add(op);
			return this;
		}
		if ("head".equals(method)) {
			if (this.heads == null) {
				this.heads = new ArrayList<>();
			}
			this.heads.add(op);
			return this;
		}
		if ("delete".equals(method)) {
			if (this.deletes == null) {
				this.deletes = new ArrayList<>();
			}
			this.deletes.add(op);
			return this;
		}
		if ("patch".equals(method)) {
			if (this.patchs == null) {
				this.patchs = new ArrayList<>();
			}
			this.patchs.add(op);
			return this;
		}
		if ("options".equals(method)) {
			if (this.optionss == null) {
				this.optionss = new ArrayList<>();
			}
			this.optionss.add(op);
			return this;
		}
		return null;
	}

	public List<Operation> getGets() {
		return this.gets;
	}

	public void setGets(List<Operation> gets) {
		this.gets = gets;
	}

	public List<Operation> getPuts() {
		return this.puts;
	}

	public void setPuts(List<Operation> puts) {
		this.puts = puts;
	}

	public List<Operation> getPosts() {
		return this.posts;
	}

	public void setPosts(List<Operation> posts) {
		this.posts = posts;
	}

	public List<Operation> getHeads() {
		return this.heads;
	}

	public void setHeads(List<Operation> heads) {
		this.heads = heads;
	}

	public List<Operation> getDeletes() {
		return this.deletes;
	}

	public void setDeletes(List<Operation> deletes) {
		this.deletes = deletes;
	}

	public List<Operation> getPatchs() {
		return this.patchs;
	}

	public void setPatchs(List<Operation> patchs) {
		this.patchs = patchs;
	}

	public List<Operation> getOptionss() {
		return this.optionss;
	}

	public void setOptionss(List<Operation> optionss) {
		this.optionss = optionss;
	}

	@JsonIgnore
	public List<Operation> getOperations() {
		List<Operation> allOperations = super.getOperations();
		if (this.gets != null) {
			allOperations.addAll(this.gets);
		}
		if (this.puts != null) {
			allOperations.addAll(this.puts);
		}
		if (this.heads != null) {
			allOperations.addAll(this.heads);
		}
		if (this.posts != null) {
			allOperations.addAll(this.posts);
		}
		if (this.deletes != null) {
			allOperations.addAll(this.deletes);
		}
		if (this.patchs != null) {
			allOperations.addAll(this.patchs);
		}
		if (this.optionss != null) {
			allOperations.addAll(this.optionss);
		}
		return allOperations;
	}
}
