package com.fzk.dto;

public class TestDTO {

	String name;
}
