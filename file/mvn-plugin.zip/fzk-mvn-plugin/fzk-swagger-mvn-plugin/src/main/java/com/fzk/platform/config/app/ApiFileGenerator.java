package com.fzk.platform.config.app;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.embedded.EmbeddedServletContainerInitializedEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import io.swagger.models.Swagger;
import springfox.documentation.service.Documentation;
import springfox.documentation.spring.web.DocumentationCache;
import springfox.documentation.spring.web.json.JsonSerializer;
import springfox.documentation.swagger2.mappers.ServiceModelToSwagger2Mapper;

@Order(Integer.MAX_VALUE)
@Component
public class ApiFileGenerator implements ApplicationListener<EmbeddedServletContainerInitializedEvent> {
	@Value("${com.fzk.api.swagger.target.file}")
	private String targetFile;
	@Value("${server.port}")
	private int port = 8080;
	
	@Autowired
	DocumentationCache documentationCache;
	@Autowired
	ServiceModelToSwagger2Mapper mapper;
	@Autowired
	JsonSerializer jsonSerializer;

	public void apiShow() {
		try {
			URL url = new URL("http://127.0.0.1:" + this.port + "/v2/api-docs");

			File file = new File(this.targetFile);
			File parentFile = file.getParentFile();
			if (!parentFile.exists()) {
				parentFile.mkdirs();
			}
			FileUtils.copyURLToFile(url, file);

			System.out.println("file copyed " + file.getAbsolutePath());
			
			Documentation documentation = documentationCache.documentationByGroup("api");
			Swagger swagger = mapper.mapDocumentation(documentation);
			System.out.println(jsonSerializer.toJson(swagger).value());
		} catch (MalformedURLException e1) {
			e1.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void onApplicationEvent(EmbeddedServletContainerInitializedEvent event) {
		apiShow();
	}
}
