
package com.fzk.platform.config.app.extend;

import io.swagger.models.Operation;
import io.swagger.models.Path;

import java.util.ArrayList;
import java.util.List;

public class ApiPath extends Path {

	private List<Operation> gets;
	private List<Operation> puts;
	private List<Operation> posts;
	private List<Operation> heads;
	private List<Operation> deletes;
	private List<Operation> patchs;
	private List<Operation> optionss;

	public ApiPath() {
	}

	public List<Operation> getGets() {
		return gets;
	}

	public void setGets(List<Operation> gets) {
		this.gets = gets;
	}

	public List<Operation> getPuts() {
		return puts;
	}

	public void setPuts(List<Operation> puts) {
		this.puts = puts;
	}

	public List<Operation> getPosts() {
		return posts;
	}

	public void setPosts(List<Operation> posts) {
		this.posts = posts;
	}

	public List<Operation> getHeads() {
		return heads;
	}

	public void setHeads(List<Operation> heads) {
		this.heads = heads;
	}

	public List<Operation> getDeletes() {
		return deletes;
	}

	public void setDeletes(List<Operation> deletes) {
		this.deletes = deletes;
	}

	public List<Operation> getPatchs() {
		return patchs;
	}

	public void setPatchs(List<Operation> patchs) {
		this.patchs = patchs;
	}

	public List<Operation> getOptionss() {
		return optionss;
	}

	public void setOptionss(List<Operation> optionss) {
		this.optionss = optionss;
	}

	public List<Operation> getOperations() {
		List<Operation> allOperations = super.getOperations();
		if (gets != null)
			allOperations.addAll(gets);
		if (puts != null)
			allOperations.addAll(puts);
		if (heads != null)
			allOperations.addAll(heads);
		if (posts != null)
			allOperations.addAll(posts);
		if (deletes != null)
			allOperations.addAll(deletes);
		if (patchs != null)
			allOperations.addAll(patchs);
		if (optionss != null)
			allOperations.addAll(optionss);
		return allOperations;
	}

	public synchronized Path set(String s, Operation operation) {
		return doSet(s, operation);
	}

	public synchronized ApiPath doSet(String method, Operation op) {
		if ("get".equals(method)) {
			if (gets == null)
				gets = new ArrayList<Operation>();
			gets.add(op);
			return this;
		}
		if ("put".equals(method)) {
			if (puts == null)
				puts = new ArrayList<Operation>();
			puts.add(op);
			return this;
		}
		if ("post".equals(method)) {
			if (posts == null)
				posts = new ArrayList<Operation>();
			posts.add(op);
			return this;
		}
		if ("head".equals(method)) {
			if (heads == null)
				heads = new ArrayList<Operation>();
			heads.add(op);
			return this;
		}
		if ("delete".equals(method)) {
			if (deletes == null)
				deletes = new ArrayList<Operation>();
			deletes.add(op);
			return this;
		}
		if ("patch".equals(method)) {
			if (patchs == null)
				patchs = new ArrayList<Operation>();
			patchs.add(op);
			return this;
		}
		if ("options".equals(method)) {
			if (optionss == null)
				optionss = new ArrayList<Operation>();
			optionss.add(op);
			return this;
		} else {
			return null;
		}
	}
}