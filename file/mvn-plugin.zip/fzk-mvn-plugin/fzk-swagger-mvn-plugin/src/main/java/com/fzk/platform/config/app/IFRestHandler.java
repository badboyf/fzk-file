package com.fzk.platform.config.app;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.reflections.Reflections;
import org.reflections.scanners.MethodAnnotationsScanner;
import org.reflections.util.ConfigurationBuilder;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.mvc.method.RequestMappingInfo;

import springfox.documentation.RequestHandler;
import springfox.documentation.spi.service.RequestHandlerProvider;

@Component
@Primary
@Order(Ordered.HIGHEST_PRECEDENCE)
public class IFRestHandler implements RequestHandlerProvider, InitializingBean {

	@Value("${com.fzk.api.swagger.package}")
	private String scanPackage;
	private IFRequestMappingHandlerMapping iFRequestMappingHandlerMapping = new IFRequestMappingHandlerMapping();
	private Map<Class<?>, Object> cacheProxyBean = new HashMap<>();
	private Set<Method> methods = new HashSet<>();
	@Value("${com.fzk.api.swagger.target.jarfile}")
	private String jarFileUrl;
	
	@Override
	public List<RequestHandler> requestHandlers() {
		List<RequestHandler> handlers = new ArrayList<>();

		for (Method method : methods) {
			Object bean = this.cacheProxyBean.get(method.getDeclaringClass());
			HandlerMethod handlerMethod = new HandlerMethod(bean, method);
			RequestMappingInfo requestMapping = this.iFRequestMappingHandlerMapping.getMappingForMethod(method, method.getDeclaringClass());
			RequestHandler handler = new IfWebMvcRequestHandler(requestMapping, handlerMethod,method.getDeclaringClass());
			handlers.add(handler);
		}

		return handlers;
	}


	@Override
	public void afterPropertiesSet() throws Exception {
		ConfigurationBuilder cb = new ConfigurationBuilder();
		URL url = new URL(this.jarFileUrl);
		cb.forPackages(scanPackage).addUrls(url).addScanners(new MethodAnnotationsScanner());
		Set<Method> methods = new Reflections(cb).getMethodsAnnotatedWith(RequestMapping.class);
		methods.removeIf(m -> !m.getDeclaringClass().isInterface());
		for (Method method : methods) {
			Class<?> declaringif = method.getDeclaringClass();
			if (this.cacheProxyBean.get(declaringif) == null) {
				Class<?>[] classes = { method.getDeclaringClass() };
				Object bean = Proxy.newProxyInstance(declaringif.getClassLoader(), classes,
						new InvocationHandler() {
							@Override
							public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
								return null;
							}
						});
				this.cacheProxyBean.put(declaringif, bean);
			}
			this.methods.addAll(methods);
		}
	}
}
