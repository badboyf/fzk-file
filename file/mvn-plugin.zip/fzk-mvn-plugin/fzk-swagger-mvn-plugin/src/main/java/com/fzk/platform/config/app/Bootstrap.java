package com.fzk.platform.config.app;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Socket;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.HashMap;
import java.util.Map;
import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.MojoFailureException;
import org.apache.maven.plugins.annotations.LifecyclePhase;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.web.client.RestTemplate;

import com.fzk.platform.config.app.extend.ServiceModelToSwagger2MapperImpl;

@SpringBootApplication
@ComponentScan({ "com.fzk" })
@EnableAutoConfiguration
@Configuration
@Mojo(name = "apijson", defaultPhase = LifecyclePhase.INSTALL)
public class Bootstrap extends AbstractMojo {
	@Parameter(property = "scanPacakge", required = true)
	private String scanPacakge;
	@Parameter(property = "filterPath", required = true)
	private String filterPath;
	@Parameter(property = "appTitle", required = true, defaultValue = "${project.name}")
	private String appTitle;
	@Parameter(property = "appDescription", required = true, defaultValue = "${project.name}")
	private String appDescription;
	@Parameter(property = "serviceUrl", required = true, defaultValue = "#")
	private String serviceUrl;
	@Parameter(property = "version", required = true, defaultValue = "${project.version}")
	private String version;
	@Parameter(property = "outJarFile", required = true, defaultValue = "file:///${project.build.directory}/${project.artifactId}-${project.version}.jar")
	private String outJarFile;
	@Parameter(property = "outPutJsonFile", required = true, defaultValue = "${project.build.directory}/api.json")
	private String outPutJsonFile;

	@Bean
	IFRequestMappingHandlerMapping ifRequestMappingHandlerMapping() {
		return new IFRequestMappingHandlerMapping();
	}

	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

	@Bean(name = { "serviceModelToSwagger2MapperImpl" })
	@Primary
	public ServiceModelToSwagger2MapperImpl servicemodel() {
		return new ServiceModelToSwagger2MapperImpl();
	}
	
	public void execute() throws MojoExecutionException, MojoFailureException {
		try {
			URL url = new URL(this.outJarFile);
			URL[] urls = { url };
			URLClassLoader classLoader = new URLClassLoader(urls, Bootstrap.class.getClassLoader());
			Thread.currentThread().setContextClassLoader(classLoader);
			SpringApplication application = new SpringApplication(new Object[] { Bootstrap.class });
			Map<String, Object> map = new HashMap<>();
			map.put("com.fzk.api.swagger.package", this.scanPacakge);
			map.put("com.fzk.api.swagger.filterPath", this.filterPath);
			map.put("com.fzk.api.swagger.app.title", this.appTitle);
			map.put("com.fzk.api.swagger.app.description", this.appDescription);
			map.put("com.fzk.api.swagger.app.service.url", this.serviceUrl);
			map.put("com.fzk.api.swagger.app.version", this.version);
			map.put("com.fzk.api.swagger.target.file", this.outPutJsonFile);
			map.put("com.fzk.api.swagger.target.jarfile", this.outJarFile);
			int port = findFreePort();
			map.put("server.port", Integer.valueOf(port));
			application.setDefaultProperties(map);
			ConfigurableApplicationContext run = application.run(new String[0]);
			run.close();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}

	private int findFreePort() {
		Socket socket = new Socket();
		InetSocketAddress inetAddress = new InetSocketAddress(0);
		try {
			socket.bind(inetAddress);
			int localPort = socket.getLocalPort();
			socket.close();
			return localPort;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return 10999;
	}
}
