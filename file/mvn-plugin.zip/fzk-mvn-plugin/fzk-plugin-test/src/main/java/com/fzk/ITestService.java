
package com.fzk;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@Api(value = "test")
public interface ITestService {
	@RequestMapping(value = "/test/{id}", method = RequestMethod.GET)
	@ApiOperation(value = "test", notes = "test")
	public void get(@ApiParam(value = "ID", name = "id", required = true) @PathVariable String id);

}
