package com.fzk;

import java.lang.reflect.Method;
import org.springframework.web.servlet.mvc.method.RequestMappingInfo;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

public class IFRequestMappingHandlerMapping extends RequestMappingHandlerMapping {
	public RequestMappingInfo getMappingForMethod(Method method, Class<?> handlerType) {
		return super.getMappingForMethod(method, handlerType);
	}
}
