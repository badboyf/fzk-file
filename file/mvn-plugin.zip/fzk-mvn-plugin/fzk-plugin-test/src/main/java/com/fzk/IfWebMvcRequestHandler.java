package com.fzk;

import java.util.List;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.mvc.method.RequestMappingInfo;
import springfox.documentation.service.ResolvedMethodParameter;
import springfox.documentation.spring.web.WebMvcRequestHandler;
import springfox.documentation.spring.web.paths.Paths;

public class IfWebMvcRequestHandler extends WebMvcRequestHandler {
	private Class<?> ifClass;

	public IfWebMvcRequestHandler(RequestMappingInfo requestMapping, HandlerMethod handlerMethod, Class<?> ifClass) {
		super(requestMapping, handlerMethod);
		this.ifClass = ifClass;
	}

	public Class<?> declaringClass() {
		return this.ifClass;
	}

	public List<ResolvedMethodParameter> getParameters() {
		return super.getParameters();
	}

	public String groupName() {
		return Paths.splitCamelCase(this.ifClass.getSimpleName(), "-").replace("/", "").toLowerCase();
	}
}
