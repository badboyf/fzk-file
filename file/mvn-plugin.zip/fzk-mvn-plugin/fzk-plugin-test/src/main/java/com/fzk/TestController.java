//package com.fzk;
//
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.fzk.ITestService;
//
//import io.swagger.annotations.ApiParam;
//
//@RestController
//public class TestController implements ITestService {
//
//	@Override
//	public void get(@ApiParam(value = "ID", name = "id", required = true) @PathVariable String id) {
//	}
//
//}
